# Home Automation Skill — Verbesserte Version

## Was hat sich gegenüber `home-assistant-agent-system-integrated` geändert?

### Struktur bereinigt (32 → 15 Dateien)

| Vorher (Problem) | Nachher (Fix) |
|---|---|
| `agent-system/dev-orchestrator/` + `agent-system/planer/` lagen verwaist — wurden nie angesteuert | Entfernt. Der generische dev-orchestrator bleibt ein **separater** Skill |
| 5 Orchestration-Dateien + 5 generische Pendants (doppeltes Material) | **1 Datei**: `orchestration/workflow.md` vereint alle 5 Phasen |
| `progress-template.md` existierte 2× identisch (188 Zeilen) | 1× in `templates/HA_PROGRESS.md` |
| Generische Templates und HA-Templates ohne Brücke | Nur noch HA-Templates — konsistent referenziert |

### Routing-Logik eingebaut

**Vorher:** SKILL.md hatte am Ende einen Absatz „für echte Projektarbeit gilt zusätzlich…" — aber keine Entscheidungslogik, wann das greift.

**Nachher:** Step 0 in SKILL.md entscheidet explizit:
- **Quick-Answer** → direkt zu Domain-Routing (wie bisher)
- **Projekt-Modus** → `orchestration/workflow.md` laden (klare Trigger-Kriterien)

### Pfade korrigiert

Die alten `orchestration/ha-knowledge-router.md` etc. referenzierten `references/part1-esphome.md` — aber vom `orchestration/`-Verzeichnis aus war der relative Pfad falsch. Jetzt steht überall der korrekte Pfad relativ zum Skill-Root.

### Description erweitert

Planungs-Keywords hinzugefügt: „plane mir ein Projekt", „V1 bauen", „wo stehen wir", „nächster Schritt", „release vorbereiten" — damit der Skill auch im Projekt-Modus triggert, nicht nur bei Fachfragen.

### Claude.ai-Hinweis

`workflow.md` enthält jetzt einen expliziten Hinweis, dass in Claude.ai keine Subagenten verfügbar sind und Tasks nacheinander abgearbeitet werden.

---

## Installation

### Als .skill-Datei (empfohlen)

Die Datei `home-automation.skill` kann direkt in Claude.ai oder Claude Code installiert werden.

### Manuell

1. `home-automation/` nach `~/.claude/skills/` oder in den Skill-Ordner deiner Wahl kopieren
2. Für Claude Code: `.claude/agents/` ins Projektverzeichnis kopieren

---

## Dateistruktur

```
home-automation/
├── SKILL.md                          ← Einstieg, Domain-Routing, Quick-Answer vs. Projekt
├── orchestration/
│   └── workflow.md                   ← 5-Phasen Projektablauf (Planung → Freigabe)
├── references/
│   ├── part1-esphome.md              ← ESPHome Framework (unverändert)
│   ├── part2-lvgl.md                 ← LVGL Graphics (unverändert)
│   ├── part3-ha-integration.md       ← HA Custom Integration + HACS (unverändert)
│   ├── part4-ha-yaml.md              ← HA YAML Automations (unverändert)
│   └── part5-openwrt.md              ← OpenWrt Integration (unverändert)
└── templates/
    ├── HA_PROGRESS.md                ← Projekt-Steuerdokument
    ├── HA_KNOWLEDGE_BRIEF.md         ← Quellen-Brief pro Task
    ├── HA_WORKING_CONTEXT.md         ← Context Checkpoint
    └── HA_RELEASE_READINESS.md       ← Release-Prüfung

.claude/agents/                       ← Nur für Claude Code
├── esphome.md
├── ha-integration.md
├── home-automation.md
└── lvgl-designer.md
```

## Hinweis zum dev-orchestrator

Der generische `dev-orchestrator`-Skill (für beliebige Software-Projekte) ist **nicht** in diesem Paket enthalten. Er ist ein eigenständiger Skill und sollte separat installiert bleiben, wenn er gebraucht wird. Dieser Skill hier deckt Home-Automation-Projekte end-to-end ab — inklusive Planung, Orchestrierung und Freigabe.
