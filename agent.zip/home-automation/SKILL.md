---
name: home-automation
description: >
  Use this skill for anything involving ESPHome — writing YAML configs for ESP32/ESP8266
  devices, building touchscreen HMI displays with LVGL, connecting sensors and displays to
  Home Assistant, or reusing configs with packages and external components. Also use for
  writing Home Assistant custom integrations in Python (coordinators, config flows, entities),
  publishing integrations to HACS, writing HA YAML automations and dashboards, or integrating
  OpenWrt routers into HA via ubus/rpcd. Trigger whenever the user is building firmware for a
  microcontroller that talks to Home Assistant, writing a custom_component, or querying a
  router from HA — even if they don't use technical terms like ESPHome or DataUpdateCoordinator.
  Also trigger for planning or managing HA projects end to end — "plane mir ein Projekt",
  "V1 bauen", "wo stehen wir", "nächster Schritt", "was fehlt noch", "release vorbereiten".
---

# Home Automation Universal Skill

## Official Documentation

| Domain | URL |
|--------|-----|
| ESPHome | https://esphome.io/ |
| ESPHome YAML guide | https://esphome.io/guides/yaml/ |
| ESPHome packages | https://esphome.io/components/packages/ |
| ESPHome substitutions | https://esphome.io/components/substitutions/ |
| ESPHome external_components | https://esphome.io/components/external_components/ |
| ESPHome LVGL | https://esphome.io/components/lvgl/ |
| HA developer docs | https://developers.home-assistant.io/ |
| HACS publish | https://www.hacs.xyz/docs/publish/integration/ |
| OpenWrt ubus | https://openwrt.org/docs/techref/ubus |

---

## Freshness Check — Veraltete Inhalte erkennen

Die Reference-Dateien (part1–part5) sind Snapshots der offiziellen Dokumentation. Sie altern.
Jede Reference-Datei enthält einen `Freshness`-Header mit Quellversion und Prüfdatum.

### Wann gegen Live-Doku prüfen (Web-Suche)

Prüfe die offizielle Doku per Web-Suche **bevor** du dich auf die Reference-Datei verlässt, wenn mindestens eines davon zutrifft:

- Der Nutzer nennt eine **konkrete Versionsnummer** (z. B. „ESPHome 2025.7", „HA 2025.8", „LVGL 9.2")
- Der Nutzer fragt nach einer **Komponente, Widget oder API, die du in der Reference-Datei nicht findest**
- Der Nutzer meldet ein **Verhalten, das der Reference-Datei widerspricht** (z. B. „das gibt einen Fehler")
- Du bist unsicher, ob eine **Syntax, ein Parameter oder ein Default-Wert** noch aktuell ist
- Die Aufgabe betrifft **HACS-Anforderungen, CI-Actions oder manifest.json-Pflichtfelder** — diese ändern sich häufig

### Wie prüfen

1. Nutze die URLs aus der Tabelle „Official Documentation" oben
2. Web-Suche mit Domain-Einschränkung, z. B. `esphome.io lvgl buttonmatrix` oder `developers.home-assistant.io config_flow`
3. Wenn die Live-Doku der Reference-Datei widerspricht: **Live-Doku gewinnt**. Weise den Nutzer darauf hin, dass sich etwas geändert hat.

### Freshness-Status der Reference-Dateien

| Datei | Basiert auf | Geprüft |
|---|---|---|
| `part1-esphome.md` | ESPHome 2024.12 | 2025-01 |
| `part2-lvgl.md` | ESPHome LVGL 2024.12 | 2025-01 |
| `part3-ha-integration.md` | HA Core 2024.12 / HACS 2.0 | 2025-01 |
| `part4-ha-yaml.md` | HA Core 2024.12 | 2025-01 |
| `part5-openwrt.md` | OpenWrt 23.05 / 24.10 | 2025-01 |

Wenn das Prüfdatum mehr als 6 Monate zurückliegt, erhöhe die Bereitschaft zur Web-Suche deutlich.

---

## Step 0: Quick-Answer vs. Projekt-Modus

**Lies diesen Abschnitt zuerst. Er entscheidet, welchen Pfad du nimmst.**

### Quick-Answer (Standard)

Nutze diesen Pfad wenn der Nutzer eine konkrete Fachfrage stellt — z. B. „wie binde ich einen Sensor an", „schreib mir eine Automation", „was ist das richtige Board für ESP32-S3". Springe direkt zu **Step 1: Domain erkennen** weiter unten.

### Projekt-Modus

Nutze diesen Pfad wenn mindestens eines davon zutrifft:
- der Nutzer will etwas Neues von Grund auf bauen
- es gibt mehrere Teilschritte oder Domänen (z. B. ESPHome + HA-Integration)
- der Nutzer fragt nach Planung, Struktur, nächsten Schritten, Status oder Release-Prüfung
- eine `HA_PROGRESS.md` existiert bereits im Projektverzeichnis

→ Lies `orchestration/workflow.md` und folge dem dortigen Ablauf.

Im Projekt-Modus lädst du trotzdem die fachlichen Reference-Dateien (part1–part5) — nur eben gesteuert über den Knowledge Router statt wahllos.

---

## Step 1: Domain erkennen → Reference File laden

**Lies nur die Reference-Datei(en), die zur aktuellen Aufgabe passen.**

Reference-Dateien liegen in `references/` neben dieser SKILL.md.

| Aufgabe | Reference File(s) |
|---|---|
| ESPHome Sensor / Device (kein Display) | `references/part1-esphome.md` |
| ESPHome LVGL HMI Display | `references/part1-esphome.md` + `references/part2-lvgl.md` |
| ESPHome ↔ HA Entity Sync | `references/part1-esphome.md` § HA Integration |
| Packages, Substitutions, !extend, !remove | `references/part1-esphome.md` § Packages |
| External Community Components | `references/part1-esphome.md` § External Components |
| Home Assistant Custom Integration (Python) | `references/part3-ha-integration.md` |
| HACS Publish / Default Store / CI Workflows | `references/part3-ha-integration.md` § HACS |
| Home Assistant YAML Automations / Scripts | `references/part4-ha-yaml.md` |
| Home Assistant Dashboard / Lovelace | `references/part4-ha-yaml.md` § Dashboards |
| OpenWrt Router Integration | `references/part5-openwrt.md` |
| OpenWrt + HA Device Tracker | `references/part3-ha-integration.md` + `references/part5-openwrt.md` |
| Full Stack: ESPHome + HA Integration | `references/part1-esphome.md` + `references/part3-ha-integration.md` |
| UX / Layout Design für Embedded Display | `references/part2-lvgl.md` § Design Guidelines |

### 3-Fragen Domain Selector

1. **ESP32/ESP8266 Mikrocontroller?** → ESPHome → `part1-esphome.md` (+ `part2-lvgl.md` bei Display)
2. **Läuft innerhalb von Home Assistant (custom_components)?** → `part3-ha-integration.md`
3. **Redet mit Router / OpenWrt?** → `part5-openwrt.md` (+ `part3-ha-integration.md` falls HA das kapselt)

---

## Reference File Contents (Inhaltsverzeichnis)

### `references/part1-esphome.md` — ESPHome Framework

- YAML Basics: Anchors, Aliases, Hidden Items, Multi-line Strings
- Secrets (`secrets.yaml`)
- Substitutions: basic, structured data, Jinja expressions, CLI overrides
- `!include` with variables
- Packages: local, remote/Git, templates, conditional, `!extend`, `!remove`
- External Components: local path, GitHub, PR shorthand, auth, refresh
- YAML Structure Order + Naming Conventions
- Hardware: ESP32-S3/PSRAM, display drivers, touchscreen controllers, backlight
- Fonts: Montserrat, MDI icons
- Lambda Reference: syntax, component access, edge case guards, type conversions
- **Home Assistant Integration:** bidirectional sync, sensor import, text sensor, HA actions, boot init

### `references/part2-lvgl.md` — LVGL Graphics Component

- LVGL Core Rules + Component Configuration
- Color & Opacity formats
- **Design Guidelines:** color palette, typography hierarchy, touch targets, ISA-101 info hierarchy
- Style Definitions: full property reference
- Layout Systems: Flex, Grid
- Widget Types: obj, label, button, buttonmatrix, switch, slider, arc, bar, meter, tabview, img
- Pages and Navigation
- Widget Actions + Universal Triggers
- Idle Screen Management
- Common Patterns: semicircle gauge, multi-state guard, platform switch integration
- Implementation Checklist + Troubleshooting table

### `references/part3-ha-integration.md` — HA Custom Integration + HACS

- Integration Architecture (full file structure)
- `manifest.json`, `const.py`, `api.py`, `coordinator.py`, `__init__.py`
- `config_flow.py`, Entity Base Pattern, `sensor.py`
- **HACS Full Publisher Reference:**
  - General requirements, repository structure (OK/Not-OK examples)
  - `hacs.json` all keys, `manifest.json` required keys
  - Brand assets (`brand/icon.png`)
  - Versioning rules (Release vs tag)
  - GitHub Actions: `hassfest.yaml`, `hacs.yaml`, `tests.yaml`
  - README template, My-Link badge
  - Default store inclusion checklist
  - `CHANGELOG.md` format
- Testing with pytest + AsyncMock

### `references/part4-ha-yaml.md` — Home Assistant YAML

- Automations: trigger types, conditions, actions, templates
- Scripts
- Template Sensors
- Dashboards / Lovelace: entity card, gauge, button card, history graph

### `references/part5-openwrt.md` — OpenWrt Integration

- Architecture: ubus, rpcd, UCI
- rpcd JSON-RPC call pattern + authentication
- Common calls: system info, network interfaces, WiFi status, connected clients/DHCP, UCI read/write, WiFi toggle
- Full `OpenWrtApi` Python class (async, token refresh, error handling)
- Device Tracker entity for OpenWrt
- Best practices table

---

## Cross-Domain Patterns (Quick Reference)

**ESPHome → HA (automatic):** Native API exposes all entities automatically. No custom Python needed for simple mirroring.

**HA state → ESPHome display:** `platform: homeassistant` sensors with `on_value` → LVGL widget update. See `part1-esphome.md` § HA Integration + `part2-lvgl.md`.

**OpenWrt → HA:** Custom HA integration (`part3`) with `api.py` calling rpcd/ubus (`part5`). DataUpdateCoordinator polls router, entities read from `coordinator.data`.

**Entities never call the network.** All HTTP in `api.py` only.

---

## Implementation Rules (Always Apply)

- Async Python only in HA — no blocking calls
- ESPHome `on_value` handlers always guard `std::isnan(x)` for HA sensors
- Use `packages:` + `substitutions:` for reusable ESPHome configs across devices
- Use `external_components:` with `refresh: never` for tagged community components
- HACS: publish a GitHub **Release** (not just a tag), include `brand/icon.png`, run both `hassfest` + `hacs/action` CI
- Semantic versioning: `v1.0.0` tags on GitHub
