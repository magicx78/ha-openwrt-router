# Part 2: LVGL Graphics Component

> **Freshness:** Basiert auf ESPHome LVGL 2024.12 · Geprüft 2025-01
> Bei Unsicherheit oder neueren Versionen: https://esphome.io/components/lvgl/ per Web-Suche gegenchecken.

---

## LVGL Core Rules

1. **IDs are ESPHome IDs** — use `id:` in YAML, access as `id(my_widget).obj` in lambdas
2. **All widget properties** go under the widget type key
3. **Styles** defined in `style_definitions` are referenced by `styles:` in widgets
4. **Actions** use `lvgl.widget.update:`, `lvgl.label.update:`, etc.
5. **Color format** in YAML: `0xRRGGBB` — in lambdas: `lv_color_hex(0xRRGGBB)`
6. **Alignment** is relative to parent by default
7. **Page transitions** supported: swipe, fade. Target 3–6 pages max.
8. **No alpha blending** on background (RGB565 = 16-bit, 65K colors)

---

## LVGL Component Configuration

```yaml
lvgl:
  color_depth: 16
  bg_color: 0x1A1A2E
  default_font: font_14

  style_definitions:
    - id: style_card
      bg_color: 0x16213E
      bg_opa: COVER
      radius: 8
      border_width: 0
      pad_all: 12

    - id: style_value_large
      text_color: 0xE0E0E0
      text_font: font_48

    - id: style_label_small
      text_color: 0x808080
      text_font: font_14

  displays:
    - my_display
  touchscreens:
    - my_touch

  pages:
    - id: page_main
      widgets:
        # widgets here

  top_layer:
    widgets:
      # persistent overlay (status bar, nav)
```

---

## Color & Opacity

```yaml
# In YAML
bg_color: 0x1A1A2E     # dark blue
text_color: 0xE0E0E0   # soft white
bg_opa: COVER          # fully opaque
bg_opa: TRANSP         # fully transparent
bg_opa: 128            # 50% (0–255)
```

```cpp
// In lambdas
lv_color_hex(0x1A1A2E)
lv_color_white()
lv_color_black()
```

---

## Design Guidelines

### Color Palette (Dark HMI Theme)

```
Background:     0x1A1A2E  deep dark blue
Card bg:        0x16213E  card surface
Accent panel:   0x0F3460  accent panels
Text primary:   0xE0E0E0  soft white (not pure 0xFFFFFF)
Text secondary: 0x808080  muted gray
Text dim:       0x404040  very dim
Active/Good:    0x00C851  green
Warning:        0xFF8800  orange — ALERTS ONLY
Error/Alarm:    0xFF3D00  red — ALARMS ONLY
Info:           0x0099FF  blue
Accent:         0x6C63FF  purple

RULE: Alarm colors (red/orange/yellow) are RESERVED for anomalies only.
Normal state uses subdued colors. Color appears only when action is needed.
```

### Typography

```
Page heading:       Montserrat 24–32px
Section label:      Montserrat 16–20px
Data value:         Montserrat 28–48px  ← BIGGER than its label
Data label:         Montserrat 12–14px
Button text:        Montserrat 16px
MDI icons:          32–48px

RULE: Values must be visually larger than their labels.
```

### Touch Target Rules (Fitts' Law)

- Minimum touch target: `w: 48, h: 48` (10mm minimum)
- Spacing between interactive elements: minimum 8px, prefer 12–16px
- Primary action = largest target on screen
- Destructive actions: small, distant, require confirmation

### Information Hierarchy (ISA-101)

```
Level 1 — Overview:    "Is everything OK?" — 2 second answer
Level 2 — Area/Room:   One subsystem detail
Level 3 — Device:      Full controls for one device
Level 4 — Settings:    Config, diagnostics (rarely accessed)

RULE: Home screen must show system health at a glance.
Every screen reachable within 1–2 taps.
```

---

## Style Definitions

```yaml
lvgl:
  style_definitions:
    - id: style_card
      bg_color: 0x16213E
      bg_opa: COVER
      radius: 8
      border_width: 0
      pad_all: 12

    - id: style_btn_primary
      bg_color: 0x6C63FF
      bg_opa: COVER
      radius: 6
      text_color: 0xFFFFFF
      text_font: font_16
      pad_all: 8

    - id: style_value
      text_color: 0xE0E0E0
      text_font: font_48

    - id: style_unit
      text_color: 0x808080
      text_font: font_14

    - id: style_alarm_active
      bg_color: 0xFF3D00
      text_color: 0xFFFFFF
```

### Complete Style Properties Reference

```yaml
# Background
bg_color: 0xRRGGBB
bg_opa: COVER | TRANSP | 0-255

# Border
border_color: 0xRRGGBB
border_width: 1
border_opa: COVER

# Text
text_color: 0xRRGGBB
text_font: font_id
text_align: LEFT | CENTER | RIGHT

# Padding (inside the object)
pad_all: 8
pad_top: 4
pad_bottom: 4
pad_left: 8
pad_right: 8

# Margin (outside the object)
pad_row: 4       # gap between rows (in layouts)
pad_column: 4    # gap between columns

# Size & position
width: 200
height: 60
min_width: 100
min_height: 40

# Radius
radius: 8
radius: 50%   # circle

# Shadow
shadow_color: 0x000000
shadow_width: 4
shadow_ofs_x: 2
shadow_ofs_y: 2
```

---

## Layout Systems

### Flex Layout

```yaml
obj:
  id: flex_container
  width: 320
  height: LV_SIZE_CONTENT
  layout:
    type: FLEX
    flex_flow: ROW             # ROW | COLUMN | ROW_WRAP | COLUMN_WRAP
    flex_align_main: CENTER    # START | END | CENTER | SPACE_EVENLY
    flex_align_cross: CENTER
    flex_align_track: CENTER
    pad_row: 8
    pad_column: 8
  widgets:
    - label:
        text: "A"
    - label:
        text: "B"
```

### Grid Layout

```yaml
obj:
  id: grid_container
  width: 320
  height: 240
  layout:
    type: GRID
    grid_columns: [FR(1), FR(1), FR(1)]   # 3 equal columns
    grid_rows: [60, 60, 60]               # 3 fixed-height rows
    pad_row: 4
    pad_column: 4
  widgets:
    - label:
        grid_cell_column_pos: 0
        grid_cell_row_pos: 0
        grid_cell_column_span: 2    # span 2 columns
        text: "Wide label"

    - button:
        grid_cell_column_pos: 2
        grid_cell_row_pos: 0
```

---

## Widget Types

### obj (Container)

```yaml
obj:
  id: card_container
  styles: style_card
  width: 150
  height: 80
  align: CENTER
  x: 0
  y: -20
  widgets:
    # child widgets here
```

### label

```yaml
label:
  id: temp_value
  text: "--"
  styles: style_value
  align: CENTER
  long_mode: CLIP     # CLIP | WRAP | SCROLL | DOTS
```

### button

```yaml
button:
  id: btn_toggle
  width: 80
  height: 48
  on_click:
    then:
      - homeassistant.action:
          action: light.toggle
          data:
            entity_id: light.living_room
  widgets:
    - label:
        text: "ON"
        align: CENTER
```

### buttonmatrix

```yaml
# Memory-efficient multi-button grid
buttonmatrix:
  id: nav_matrix
  width: 320
  height: 60
  align: BOTTOM_MID
  y: -4
  one_checked: true    # radio-button behavior
  styles: style_card
  items:
    styles: style_btn_primary
  rows:
    - buttons:
        - id: btn_home
          text: "\U000F06D4"  # mdi:home
          checkable: true
          checked: true
        - id: btn_energy
          text: "\U000F06A5"  # mdi:lightning-bolt
          checkable: true
        - id: btn_climate
          text: "\U000F050F"  # mdi:thermometer
          checkable: true
  on_matrix_button_pressed:
    - lambda: |-
        if (id(btn_home).state) {
          lv_scr_load_anim(id(page_main).obj, LV_SCR_LOAD_ANIM_MOVE_RIGHT, 200, 0, false);
        } else if (id(btn_energy).state) {
          lv_scr_load_anim(id(page_energy).obj, LV_SCR_LOAD_ANIM_MOVE_LEFT, 200, 0, false);
        }
```

### switch

```yaml
switch:
  id: sw_device
  width: 60
  height: 32
  align: RIGHT_MID
  x: -8
```

```yaml
# LVGL platform switch for HA sync
switch:
  - platform: lvgl
    widget: sw_device
    name: "My Device Switch"
```

### slider

```yaml
slider:
  id: brightness_slider
  width: 200
  height: 16
  min_value: 0
  max_value: 100
  value: 50
  on_value:
    then:
      - homeassistant.action:
          action: light.turn_on
          data:
            entity_id: light.living_room
            brightness_pct: !lambda return (int)x;
```

### arc

```yaml
arc:
  id: battery_arc
  width: 120
  height: 120
  align: CENTER
  arc_color: 0x00C851
  arc_width: 8
  indicator:
    arc_color: 0x404040
    arc_width: 8
  min_value: 0
  max_value: 100
  value: 75
  mode: NORMAL    # NORMAL | REVERSE | SYMMETRICAL
  adjustable: false
```

### meter

```yaml
meter:
  id: power_meter
  width: 200
  height: 200
  align: CENTER
  scales:
    - ticks:
        count: 9
        width: 2
        length: 8
        color: 0x808080
      range_from: 0
      range_to: 4000
      angle_range: 240
      rotation: 150
      indicators:
        - needle_line:
            id: power_needle
            width: 3
            color: 0xFF8800
            r_mod: -10
            value: 0
        - arc:
            color: 0x00C851
            width: 6
            r_mod: -18
            start_value: 0
            end_value: 0
            id: power_arc
```

### bar

```yaml
bar:
  id: soc_bar
  width: 180
  height: 12
  min_value: 0
  max_value: 100
  value: 80
  indicator:
    bg_color: 0x00C851
```

### tabview

```yaml
tabview:
  id: tabs
  width: 320
  height: 240
  tab_pos: TOP
  tab_width: 80
  tabs:
    - id: tab_home
      name: "Home"
      widgets:
        - label:
            text: "Home content"
    - id: tab_energy
      name: "Energy"
      widgets:
        - label:
            text: "Energy content"
```

### img (Image)

```yaml
image:
  - file: mdi:weather-sunny
    id: img_sunny
    resize: 48x48

# In widget:
img:
  id: weather_img
  src: img_sunny
  align: CENTER
```

---

## Pages and Navigation

```yaml
lvgl:
  pages:
    - id: page_home
      widgets:
        - label:
            id: lbl_time
            text: "00:00"
            align: TOP_MID
            y: 8

    - id: page_energy
      on_load:
        - lambda: |-
            // refresh data when page becomes active
            id(solar_power).update();
      widgets:
        - label:
            text: "Energy"

  # Swipe navigation between pages
  on_idle:
    timeout: 30s
    then:
      - lvgl.page.show: page_home

# Navigate from code or button:
- lvgl.page.show:
    id: page_energy
    animation: MOVE_LEFT
    time: 200ms

# Navigate from lambda:
lv_scr_load_anim(id(page_energy).obj, LV_SCR_LOAD_ANIM_MOVE_LEFT, 200, 0, false);
```

---

## Widget Actions (Universal)

```yaml
# Update widget state
- lvgl.widget.update:
    id: my_widget
    hidden: false
    disabled: true

# Update label specifically
- lvgl.label.update:
    id: my_label
    text: "New text"

# Update arc value
- lvgl.arc.update:
    id: my_arc
    value: 75

# Update indicator (meter needle)
- lvgl.indicator.update:
    id: my_needle
    value: 1500
```

---

## Idle Screen Management

```yaml
lvgl:
  on_idle:
    timeout: 60s
    then:
      - light.turn_off: backlight
      - lvgl.page.show: page_home

  on_activity:
    then:
      - light.turn_on: backlight
```

---

## Common LVGL Patterns

### Semicircle Gauge

```yaml
meter:
  id: temp_gauge
  width: 180
  height: 180
  scales:
    - ticks:
        count: 11
        width: 2
        length: 10
        color: 0x404040
      range_from: 0
      range_to: 100
      angle_range: 180
      rotation: 180
      indicators:
        - needle_line:
            id: temp_needle
            width: 3
            color: 0x00C851
            r_mod: -5
            value: 0
        - arc:
            id: temp_arc
            color: 0x00C851
            width: 8
            r_mod: -14
            start_value: 0
            end_value: 0
```

### Multi-State UI (View / Edit Mode Guard Pattern)

```yaml
globals:
  - id: edit_mode
    type: bool
    initial_value: "false"

# Guard pattern prevents feedback loops
switch:
  - platform: homeassistant
    id: ha_device
    entity_id: switch.device
    on_state:
      - if:
          condition:
            lambda: return !id(edit_mode);
          then:
            - lvgl.widget.update:
                id: sw_device
                state:
                  checked: !lambda return x;
```

### Platform Switch Integration

```yaml
switch:
  # Import state from HA
  - platform: homeassistant
    id: ha_light
    entity_id: light.kitchen
    on_state:
      - lvgl.widget.update:
          id: sw_light
          state:
            checked: !lambda return x;

  # LVGL ↔ HA bidirectional
  - platform: lvgl
    widget: sw_light
    name: "Kitchen Light"

# In LVGL:
lvgl:
  pages:
    - id: page_main
      widgets:
        - switch:
            id: sw_light
            align: RIGHT_MID
            x: -8
```

### Multi-Page Touch Navigation

```yaml
lvgl:
  pages:
    - id: page_0
    - id: page_1
    - id: page_2

binary_sensor:
  - platform: touchscreen
    id: swipe_detector
    # use template sensors or gesture detection
```

---

## Implementation Checklist

Before delivering any LVGL config, verify:

- [ ] All widget IDs are unique and follow naming conventions
- [ ] All referenced font IDs are defined in `font:` section
- [ ] All referenced image IDs are defined in `image:` section
- [ ] All referenced style IDs are defined in `style_definitions`
- [ ] HA sensor `on_value` handlers guard against `std::isnan(x)`
- [ ] Touch targets are at minimum 48×48px
- [ ] Meter needle IDs are defined as `indicator` inside scales
- [ ] Platform switches have corresponding `homeassistant` imports
- [ ] Boot initialization covers all HA-dependent widgets
- [ ] No alarm colors used for decoration (only for actual alarms)

---

## Troubleshooting

| Symptom | Likely Cause | Fix |
|---------|-------------|-----|
| Widget not visible | Missing `width`/`height`, or parent too small | Add explicit dimensions |
| Text not showing | Font not defined, or glyph missing | Check `font:` section; add glyph to `extras:` |
| Meter needle not moving | Indicator ID wrong, or value out of range | Check `range_from`/`range_to`, verify indicator ID |
| Touch not responding | Calibration off, or target too small | Check `transform:`, ensure 48×48 minimum |
| Lambda compile error | Missing `id()`, wrong C++ syntax | Check component IDs, use `lv_obj_t *obj = id(x).obj;` |
| NaN on display | HA entity unavailable at boot | Add `if (!std::isnan(x))` guard |
| PSRAM allocation error | Buffers too large for available RAM | Reduce `color_depth`, buffer sizes, or page count |

---
---