# Part 3: Home Assistant Custom Integration

> **Freshness:** Basiert auf HA Core 2024.12 / HACS 2.0 · Geprüft 2025-01
> HACS-Anforderungen und manifest.json-Felder ändern sich häufig — bei Publish-Fragen immer https://www.hacs.xyz/docs/publish/integration/ und https://developers.home-assistant.io/ gegenchecken.

---

## Integration Architecture

```
custom_components/
└── my_integration/
    ├── __init__.py          # Domain setup, async_setup_entry
    ├── manifest.json        # Integration metadata
    ├── const.py             # Constants (DOMAIN, keys, defaults)
    ├── coordinator.py       # DataUpdateCoordinator
    ├── api.py               # All network calls here
    ├── config_flow.py       # UI setup wizard
    ├── sensor.py            # Sensor entities
    ├── switch.py            # Switch entities
    ├── binary_sensor.py     # Binary sensor entities
    ├── button.py            # Button entities
    ├── device_tracker.py    # Device tracker entities
    ├── select.py            # Select entities
    ├── number.py            # Number entities
    ├── diagnostics.py       # HA diagnostics support
    ├── strings.json         # UI strings
    └── translations/
        └── en.json
```

---

## manifest.json

```json
{
  "domain": "my_integration",
  "name": "My Integration",
  "codeowners": ["@github_username"],
  "config_flow": true,
  "documentation": "https://github.com/user/repo",
  "integration_type": "device",
  "iot_class": "local_polling",
  "requirements": ["aiohttp>=3.8.0"],
  "version": "0.1.0"
}
```

---

## const.py

```python
DOMAIN = "my_integration"
DEFAULT_SCAN_INTERVAL = 30
DEFAULT_PORT = 80
DEFAULT_TIMEOUT = 10

CONF_HOST = "host"
CONF_USERNAME = "username"
CONF_PASSWORD = "password"

ATTR_UPTIME = "uptime"
ATTR_FIRMWARE = "firmware_version"
```

---

## api.py — Network Layer

```python
"""All network calls isolated in this module."""
from __future__ import annotations
import asyncio
import logging
from typing import Any

import aiohttp

_LOGGER = logging.getLogger(__name__)


class MyDeviceApiError(Exception):
    """Raised when the API returns an error."""


class MyDeviceApi:
    """Async API client for my device."""

    def __init__(
        self,
        host: str,
        username: str,
        password: str,
        session: aiohttp.ClientSession,
        timeout: int = 10,
    ) -> None:
        self._host = host
        self._username = username
        self._password = password
        self._session = session
        self._timeout = aiohttp.ClientTimeout(total=timeout)

    async def async_get_status(self) -> dict[str, Any]:
        """Fetch device status."""
        try:
            async with self._session.get(
                f"http://{self._host}/api/status",
                auth=aiohttp.BasicAuth(self._username, self._password),
                timeout=self._timeout,
            ) as resp:
                resp.raise_for_status()
                return await resp.json()
        except aiohttp.ClientError as err:
            raise MyDeviceApiError(f"API error: {err}") from err
        except asyncio.TimeoutError as err:
            raise MyDeviceApiError("Connection timeout") from err

    async def async_test_connection(self) -> bool:
        """Test if device is reachable. Used in config flow."""
        try:
            await self.async_get_status()
            return True
        except MyDeviceApiError:
            return False
```

---

## coordinator.py

```python
"""DataUpdateCoordinator for my integration."""
from __future__ import annotations
import logging
from datetime import timedelta
from typing import Any

from homeassistant.core import HomeAssistant
from homeassistant.helpers.update_coordinator import DataUpdateCoordinator, UpdateFailed

from .api import MyDeviceApi, MyDeviceApiError
from .const import DOMAIN, DEFAULT_SCAN_INTERVAL

_LOGGER = logging.getLogger(__name__)


class MyDeviceCoordinator(DataUpdateCoordinator[dict[str, Any]]):
    """Manages polling and data distribution to all entities."""

    def __init__(
        self,
        hass: HomeAssistant,
        api: MyDeviceApi,
        scan_interval: int = DEFAULT_SCAN_INTERVAL,
    ) -> None:
        super().__init__(
            hass,
            _LOGGER,
            name=DOMAIN,
            update_interval=timedelta(seconds=scan_interval),
        )
        self.api = api

    async def _async_update_data(self) -> dict[str, Any]:
        """Fetch data from device. Called by HA on schedule."""
        try:
            return await self.api.async_get_status()
        except MyDeviceApiError as err:
            raise UpdateFailed(f"Error fetching data: {err}") from err
```

---

## __init__.py

```python
"""My Integration setup."""
from __future__ import annotations
import logging

import aiohttp
from homeassistant.config_entries import ConfigEntry
from homeassistant.const import Platform
from homeassistant.core import HomeAssistant
from homeassistant.helpers.aiohttp_client import async_get_clientsession

from .api import MyDeviceApi
from .coordinator import MyDeviceCoordinator
from .const import DOMAIN, CONF_HOST, CONF_USERNAME, CONF_PASSWORD

_LOGGER = logging.getLogger(__name__)

PLATFORMS = [Platform.SENSOR, Platform.SWITCH, Platform.BINARY_SENSOR]


async def async_setup_entry(hass: HomeAssistant, entry: ConfigEntry) -> bool:
    """Set up integration from a config entry."""
    session = async_get_clientsession(hass)
    api = MyDeviceApi(
        host=entry.data[CONF_HOST],
        username=entry.data[CONF_USERNAME],
        password=entry.data[CONF_PASSWORD],
        session=session,
    )
    coordinator = MyDeviceCoordinator(hass, api)
    await coordinator.async_config_entry_first_refresh()

    hass.data.setdefault(DOMAIN, {})[entry.entry_id] = coordinator
    await hass.config_entries.async_forward_entry_setups(entry, PLATFORMS)
    return True


async def async_unload_entry(hass: HomeAssistant, entry: ConfigEntry) -> bool:
    """Unload a config entry."""
    if unload_ok := await hass.config_entries.async_unload_platforms(entry, PLATFORMS):
        hass.data[DOMAIN].pop(entry.entry_id)
    return unload_ok
```

---

## config_flow.py

```python
"""Config flow for my integration."""
from __future__ import annotations
import logging
from typing import Any

import aiohttp
import voluptuous as vol

from homeassistant.config_entries import ConfigFlow, ConfigFlowResult
from homeassistant.const import CONF_HOST, CONF_PASSWORD, CONF_USERNAME
from homeassistant.helpers.aiohttp_client import async_get_clientsession

from .api import MyDeviceApi
from .const import DOMAIN

_LOGGER = logging.getLogger(__name__)

STEP_USER_DATA_SCHEMA = vol.Schema(
    {
        vol.Required(CONF_HOST): str,
        vol.Required(CONF_USERNAME): str,
        vol.Required(CONF_PASSWORD): str,
    }
)


class MyIntegrationConfigFlow(ConfigFlow, domain=DOMAIN):
    """Handle a config flow for my integration."""

    VERSION = 1

    async def async_step_user(
        self, user_input: dict[str, Any] | None = None
    ) -> ConfigFlowResult:
        errors: dict[str, str] = {}

        if user_input is not None:
            session = async_get_clientsession(self.hass)
            api = MyDeviceApi(
                host=user_input[CONF_HOST],
                username=user_input[CONF_USERNAME],
                password=user_input[CONF_PASSWORD],
                session=session,
            )
            if await api.async_test_connection():
                await self.async_set_unique_id(user_input[CONF_HOST])
                self._abort_if_unique_id_configured()
                return self.async_create_entry(
                    title=user_input[CONF_HOST],
                    data=user_input,
                )
            else:
                errors["base"] = "cannot_connect"

        return self.async_show_form(
            step_id="user",
            data_schema=STEP_USER_DATA_SCHEMA,
            errors=errors,
        )
```

---

## Entity Base Pattern

```python
"""Base entity class (shared by all platforms)."""
from __future__ import annotations

from homeassistant.helpers.device_registry import DeviceInfo
from homeassistant.helpers.update_coordinator import CoordinatorEntity

from .const import DOMAIN
from .coordinator import MyDeviceCoordinator


class MyDeviceEntity(CoordinatorEntity[MyDeviceCoordinator]):
    """Base entity class. All entities inherit from this."""

    _attr_has_entity_name = True

    def __init__(
        self,
        coordinator: MyDeviceCoordinator,
        unique_id_suffix: str,
    ) -> None:
        super().__init__(coordinator)
        self._attr_unique_id = f"{coordinator.config_entry.entry_id}_{unique_id_suffix}"

    @property
    def device_info(self) -> DeviceInfo:
        """Return device info (groups all entities under one device)."""
        return DeviceInfo(
            identifiers={(DOMAIN, self.coordinator.config_entry.entry_id)},
            name=self.coordinator.config_entry.title,
            manufacturer="My Manufacturer",
            model="My Device Model",
        )
```

---

## sensor.py

```python
"""Sensor platform."""
from __future__ import annotations
from dataclasses import dataclass

from homeassistant.components.sensor import (
    SensorDeviceClass,
    SensorEntity,
    SensorEntityDescription,
    SensorStateClass,
)
from homeassistant.const import UnitOfTemperature, PERCENTAGE
from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant
from homeassistant.helpers.entity_platform import AddEntitiesCallback

from .const import DOMAIN
from .coordinator import MyDeviceCoordinator
from .entity import MyDeviceEntity


@dataclass(frozen=True)
class MyDeviceSensorEntityDescription(SensorEntityDescription):
    """Extended sensor description."""
    data_key: str = ""


SENSORS: tuple[MyDeviceSensorEntityDescription, ...] = (
    MyDeviceSensorEntityDescription(
        key="temperature",
        data_key="temperature",
        name="Temperature",
        native_unit_of_measurement=UnitOfTemperature.CELSIUS,
        device_class=SensorDeviceClass.TEMPERATURE,
        state_class=SensorStateClass.MEASUREMENT,
    ),
    MyDeviceSensorEntityDescription(
        key="humidity",
        data_key="humidity",
        name="Humidity",
        native_unit_of_measurement=PERCENTAGE,
        device_class=SensorDeviceClass.HUMIDITY,
        state_class=SensorStateClass.MEASUREMENT,
    ),
)


async def async_setup_entry(
    hass: HomeAssistant,
    entry: ConfigEntry,
    async_add_entities: AddEntitiesCallback,
) -> None:
    coordinator: MyDeviceCoordinator = hass.data[DOMAIN][entry.entry_id]
    async_add_entities(
        MyDeviceSensor(coordinator, description) for description in SENSORS
    )


class MyDeviceSensor(MyDeviceEntity, SensorEntity):
    """A sensor entity."""

    entity_description: MyDeviceSensorEntityDescription

    def __init__(
        self,
        coordinator: MyDeviceCoordinator,
        description: MyDeviceSensorEntityDescription,
    ) -> None:
        super().__init__(coordinator, description.key)
        self.entity_description = description

    @property
    def native_value(self) -> float | None:
        """Return current value."""
        return self.coordinator.data.get(self.entity_description.data_key)
```

---

## HACS Compatibility

For a HACS-compatible integration, ensure:

1. **Repository structure:**
   ```
   custom_components/
   └── my_integration/
       ├── manifest.json    ← required
       └── ...
   hacs.json                ← required
   ```

2. **hacs.json:**
   ```json
   {
     "name": "My Integration",
     "render_readme": true
   }
   ```

3. **manifest.json** must have: `domain`, `name`, `version`, `documentation`, `codeowners`

4. **README.md** must exist with description

5. **Releases:** use semantic versioning tags (`v1.0.0`) on GitHub

---

## Testing

```python
# tests/test_api.py
import pytest
from unittest.mock import AsyncMock, MagicMock, patch
from custom_components.my_integration.api import MyDeviceApi, MyDeviceApiError


@pytest.fixture
def mock_session():
    session = MagicMock()
    session.get = AsyncMock()
    return session


@pytest.fixture
def api(mock_session):
    return MyDeviceApi("192.168.1.1", "admin", "password", mock_session)


async def test_get_status_success(api, mock_session):
    mock_response = AsyncMock()
    mock_response.json = AsyncMock(return_value={"temperature": 21.5})
    mock_response.raise_for_status = MagicMock()
    mock_session.get.return_value.__aenter__ = AsyncMock(return_value=mock_response)
    mock_session.get.return_value.__aexit__ = AsyncMock(return_value=False)

    result = await api.async_get_status()
    assert result["temperature"] == 21.5


async def test_get_status_connection_error(api, mock_session):
    import aiohttp
    mock_session.get.return_value.__aenter__ = AsyncMock(
        side_effect=aiohttp.ClientError("Connection refused")
    )
    mock_session.get.return_value.__aexit__ = AsyncMock(return_value=False)

    with pytest.raises(MyDeviceApiError):
        await api.async_get_status()
```

---

## HACS — Full Publisher Reference

HACS (Home Assistant Community Store) lets users install your integration through a UI.
There are two levels: **custom repository** (user adds your repo manually) and
**default store** (your repo is included in HACS by default after review).

### General Requirements (Both Levels)

| Requirement | Detail |
|-------------|--------|
| Public GitHub repository | Private repos are not supported |
| Repository description | Short sentence shown in HACS UI |
| Repository topics | Not shown in UI, but improve searchability |
| `README.md` | Must explain what the integration does and how to use it |
| `hacs.json` | HACS manifest — must be in repo root |
| At least one GitHub Release | Just pushing tags is not enough — create a full Release |

### Repository Structure

The only valid structure is:

```
your-repo/
├── custom_components/
│   └── your_domain/         ← exactly ONE integration per repo
│       ├── __init__.py
│       ├── manifest.json
│       ├── sensor.py
│       └── ...
├── brand/
│   └── icon.png             ← required for default store
├── hacs.json                ← required, in root
├── README.md                ← required
└── CHANGELOG.md             ← strongly recommended
```

❌ Not OK — files in `awesome/` instead of `custom_components/awesome/`
❌ Not OK — files directly in root (unless `content_in_root: true` in hacs.json, but avoid this)

### hacs.json — All Keys

```json
{
  "name": "My Integration",
  "homeassistant": "2024.1.0",
  "hacs": "2.0.0",
  "hide_default_branch": false,
  "persistent_directory": "userfiles"
}
```

| Key | Type | Required | Description |
|-----|------|----------|-------------|
| `name` | string | **Yes** | Display name shown in HACS UI |
| `homeassistant` | string | No | Minimum required HA version |
| `hacs` | string | No | Minimum required HACS version |
| `hide_default_branch` | bool | No | Hide default branch from download options |
| `persistent_directory` | string | No | Relative path inside integration dir preserved during upgrades |
| `content_in_root` | bool | No | Files are in repo root (avoid for integrations) |
| `zip_release` | bool | No | Content is in a zip archive in releases (integrations only) |
| `filename` | string | No | Specific filename HACS should use (for zip releases) |
| `country` | string/list | No | ISO 3166-1 alpha-2 country code(s) for region-specific integrations |

Append `b0` to `homeassistant` version to allow HA beta versions:
```json
{ "name": "My Integration", "homeassistant": "2024.1.0b0" }
```

### manifest.json — Required Keys for HACS

HACS requires these keys in addition to normal HA manifest keys:

```json
{
  "domain": "my_integration",
  "name": "My Integration",
  "documentation": "https://github.com/user/repo",
  "issue_tracker": "https://github.com/user/repo/issues",
  "codeowners": ["@github_username"],
  "version": "1.0.0",
  "config_flow": true,
  "iot_class": "local_polling",
  "requirements": []
}
```

Required by HACS: `domain`, `name`, `documentation`, `issue_tracker`, `codeowners`, `version`

### Brand Assets

Required for default store inclusion, strongly recommended otherwise:

```
brand/
├── icon.png          ← 256×256px, required
├── icon@2x.png       ← 512×512px, optional
└── logo.png          ← optional
```

### Versioning Rules

- Use semantic versioning: `1.0.0`, `1.1.0`, `2.0.0`
- Create a **GitHub Release** (not just a tag) — HACS reads the release tag
- HACS shows the 5 latest releases in the download UI
- Without releases: HACS uses the first 7 characters of the latest commit hash

### GitHub Actions CI (Recommended Workflows)

Add these two workflow files to every integration repo:

```yaml
# .github/workflows/hassfest.yaml
# Validates integration structure and manifest — required for default store
name: Validate with hassfest

on:
  push:
  pull_request:
  schedule:
    - cron: "0 0 * * *"

jobs:
  validate:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: home-assistant/actions/hassfest@master
```

```yaml
# .github/workflows/hacs.yaml
# Validates HACS repository requirements
name: Validate with HACS

on:
  push:
  pull_request:
  schedule:
    - cron: "0 0 * * *"

jobs:
  validate:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: hacs/action@main
        with:
          CATEGORY: integration
```

```yaml
# .github/workflows/tests.yaml
# Run pytest on every push/PR
name: Tests

on:
  push:
  pull_request:

jobs:
  tests:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with:
          python-version: "3.12"
      - run: pip install pytest pytest-asyncio aiohttp homeassistant
      - run: pytest tests/ -v
```

### README.md Minimum Content

```markdown
# My Integration

[![hacs_badge](https://img.shields.io/badge/HACS-Default-orange.svg)](https://github.com/hacs/integration)
[![GitHub Release](https://img.shields.io/github/release/user/repo.svg)](https://github.com/user/repo/releases)

Integrates [Device X] with Home Assistant.

## Installation

### HACS (recommended)
1. Open HACS in Home Assistant
2. Search for "My Integration"
3. Download and restart HA

### Manual
1. Copy `custom_components/my_integration/` to your HA config directory
2. Restart Home Assistant

## Configuration
Go to Settings → Devices & Services → Add Integration → "My Integration"

## Supported Devices
- Model A (firmware 2.0+)
- Model B

## Contributing
See [CONTRIBUTING.md](CONTRIBUTING.md)
```

### My-Link Badge for Documentation

Generate a one-click add-to-HACS link at:
`https://my.home-assistant.io/create-link/?redirect=hacs_repository`

Use in README:
```markdown
[![Open your Home Assistant instance and open a repository inside the Home Assistant Community Store.](https://my.home-assistant.io/badges/hacs_repository.svg)](https://my.home-assistant.io/redirect/hacs_repository/?owner=YOUR_USER&repository=YOUR_REPO&category=integration)
```

### HACS Default Store Inclusion Checklist

To get your repo into the HACS default store (PR to `hacs/default`):

- [ ] All general requirements met (above)
- [ ] All integration requirements met (above)
- [ ] `brand/icon.png` present (256×256px)
- [ ] `hassfest` GitHub Action passing
- [ ] `hacs/action` GitHub Action passing
- [ ] At least one GitHub Release published
- [ ] Repository is active (not archived)
- [ ] Submitter is owner or major contributor
- [ ] PR submitted to `hacs/default` — entry added alphabetically
- [ ] PR branch created from `master` (not master branch directly)
- [ ] Country code set in `hacs.json` if region-specific

> Note: Default store review takes months. Custom repository works immediately.

### CHANGELOG.md Format

```markdown
# Changelog

## [1.1.0] - 2026-03-01
### Added
- Support for firmware 3.x
- New `energy` sensor entity

### Fixed
- Token refresh no longer fails after HA restart

### Changed
- Polling interval now configurable in options flow

## [1.0.0] - 2026-01-15
### Added
- Initial release
- Config flow setup
- Sensor and switch entities
```

---
---