# Part 1: ESPHome Framework

> **Freshness:** Basiert auf ESPHome 2024.12 · Geprüft 2025-01
> Bei Unsicherheit oder neueren Versionen: https://esphome.io/ per Web-Suche gegenchecken.

---

## YAML Basics for ESPHome

ESPHome uses standard YAML with several extensions. Key rules:

- **Order is irrelevant** — the entire file is parsed before any processing
- **2-space indentation** is the standard
- **Booleans:** `true`/`false`, also `yes`/`on`/`enable` → true, `no`/`off`/`disable` → false
- **`#`** starts a comment
- **Sequences:** use `-` prefix (YAML style) or `[ ... ]` (JSON style)

### YAML Anchors and Aliases

Reuse configuration blocks without duplication:

```yaml
sensor:
  - &common_adc
    pin: GPIO32
    platform: adc
    name: "Temperature 1"
    device_class: temperature
    unit_of_measurement: "°C"
    accuracy_decimals: 1

  - <<: *common_adc
    pin: GPIO33
    name: "Temperature 2"
```

### Hidden Items (Dot-prefix)

Top-level keys starting with `.` are ignored — useful for defining anchors outside the config:

```yaml
.defaults: &defaults
  optimistic: true
  min_value: 0
  max_value: 600
  step: 1

number:
  - platform: template
    <<: *defaults
    id: delay_setting
    name: "Main Switch Delay"
```

### Multi-line Strings

Use `|-` (literal, strip trailing newlines) for lambdas and long strings:

```yaml
on_value:
  then:
    - lambda: |-
        auto val = x;
        lv_label_set_text_fmt(id(my_label).obj, "%.1f W", val);
```

---

## Secrets

Sensitive values go in `secrets.yaml` (never commit to git):

```yaml
# secrets.yaml
wifi_password: my_super_secret_password
api_key: abc123def456

# In device config:
wifi:
  ssid: "MyWiFi"
  password: !secret wifi_password
```

---

## Substitutions

Define reusable variables, override per-device. Case-sensitive. `$var` or `${var}` syntax.

```yaml
substitutions:
  device_name: kitchen-display
  friendly_name: Kitchen Display
  display_width: "800"
  display_height: "480"
  bme280_offset: "-1.0"

esphome:
  name: ${device_name}

sensor:
  - platform: bme280_i2c
    temperature:
      name: "${friendly_name} Temperature"
      filters:
        - offset: ${bme280_offset}
```

### Substitutions as Structured Data

```yaml
substitutions:
  device:
    name: Kitchen AC
    port: 12
    enabled: true
  unused_pins: [12, 23, 27]
  sensor_pin:
    number: 3
    inverted: true

binary_sensor:
  - platform: gpio
    name: "Sensor on pin ${sensor_pin.number}"
    pin: ${sensor_pin}
```

### Jinja Expressions in Substitutions

```yaml
substitutions:
  native_width: 480
  native_height: 320
  high_dpi: true
  scale: 1.5

display:
  - platform: ili9xxx
    dimensions:
      width: ${native_width * 2 if high_dpi else native_width}
      height: ${native_height * 2 if high_dpi else native_height}
```

Built-in Jinja functions: `ord`, `chr`, `len`, `math.*` (Python math library).

Disable substitution processing with `!literal`:

```yaml
lvgl:
  widgets:
    - label:
        text: !literal "This is a ${value}"  # not substituted
```

### Command-line Substitutions

```bash
esphome -s name my_device01 -s location kitchen config example.yaml
```

Command-line substitutions override all others.

### Two-pass Substitution

```yaml
substitutions:
  foo: yellow
  bar:
    yellow: !secret yellow_secret
    green: !secret green_secret

something:
  test: ${bar[foo]}   # resolves to bar.yellow
```

---

## !include

Insert the contents of another YAML file inline:

```yaml
binary_sensor:
  - platform: gpio
    id: button1
    pin: GPIOXX
    # inline syntax with variables
    on_multi_click: !include { file: on-multi-click.yaml, vars: { id: 1 } }

  - platform: gpio
    id: button2
    pin: GPIOXX
    # multi-line syntax
    on_multi_click: !include
      file: on-multi-click.yaml
      vars:
        id: 2
```

Variables passed via `vars:` are available as substitutions inside the included file.

---

## Packages

Packages split configs into reusable, mergeable fragments.

**Merge rules:**
- Dictionaries merge key-by-key
- Lists merge by component ID (if specified), otherwise by concatenation
- Main config values override package values
- Substitutions in main config override package substitutions

### Local Packages

```yaml
# config.yaml — as a list
packages:
  - !include common/wifi.yaml
  - !include common/device_base.yaml

# Add device-specific overrides after
api:
  actions:
    - action: start_laundry
      then:
        - switch.turn_on: relay
```

```yaml
# common/wifi.yaml
wifi:
  ssid: !secret wifi_ssid
  password: !secret wifi_password
```

```yaml
# common/device_base.yaml
esphome:
  name: ${node_name}

esp32:
  board: wemos_d1_mini32

logger:

api:
  encryption:
    key: !secret api_encryption_key
```

### Remote / Git Packages

```yaml
packages:
  # GitHub shorthand
  remote_package: github://esphome/non-existant-repo/file1.yml@main

  # Full syntax with multiple files
  remote_full:
    url: https://github.com/esphome/non-existant-repo
    files: [file1.yml, file2.yml]
    ref: main
    refresh: 1d

  # Files with per-file variables
  remote_vars:
    url: https://github.com/esphome/non-existant-repo
    files:
      - path: file1.yml
        vars:
          a: 1
          b: 2
      - path: file1.yml    # same file, different vars
        vars:
          a: 3
          b: 4
    ref: main
    refresh: 1d
```

> Remote packages cannot use `!secret` — use substitutions with defaults instead.

### Packages as Templates

Reuse complex configs with different variables:

```yaml
# config.yaml
packages:
  left_door:   !include { file: garage-door.yaml, vars: { door_name: Left,   relay_pin: GPIO1 } }
  middle_door: !include { file: garage-door.yaml, vars: { door_name: Middle, relay_pin: GPIO2 } }
  right_door:  !include { file: garage-door.yaml, vars: { door_name: Right,  relay_pin: GPIO3 } }
```

```yaml
# garage-door.yaml
switch:
  - name: ${door_name} Garage Door Switch
    platform: gpio
    pin: ${relay_pin}
```

### Conditionally Including a Package

```yaml
substitutions:
  enable_display: true

packages:
  display_pkg: ${ "!include display.yaml" if enable_display else {} }
```

### !extend — Modifying Included Configs

Override specific fields in a packaged component by ID:

```yaml
# common.yaml has: sensor id: uptime_sensor, update_interval: 5min
packages:
  - !include common.yaml

sensor:
  - id: !extend uptime_sensor
    update_interval: 10s   # override only this field
```

LVGL hierarchies work too:

```yaml
packages:
  - !include interface.yaml   # has lvgl page id: main_page, label id: title_label

lvgl:
  pages:
    - id: !extend main_page
      widgets:
        - label:
            id: !extend title_label
            text: "New Title"
            text_color: red
```

`!extend` works with substitutions and Jinja:

```yaml
substitutions:
  switches: [left_switch, right_switch, center_switch]
  mains_switch: 1

switch:
  - id: !extend ${ switches[mains_switch] }
    name: "Mains switch"
```

### !remove — Removing Packaged Entries

```yaml
packages:
  - !include common.yaml

# Remove an entire component by ID
sensor:
  - id: !remove uptime_sensor

# Remove a top-level key entirely
captive_portal: !remove

# Remove only one attribute
sensor:
  - id: !extend uptime_sensor
    update_interval: !remove

# Remove an LVGL widget by ID
lvgl:
  pages:
    - id: !extend main_page
      widgets:
        - label:
            id: !remove title_label
```

### YAML Insertion Operator (Single-file Inheritance)

```yaml
# common.yaml
esphome:
  name: $devicename
sensor:
  - platform: dht
    temperature:
      name: Temperature

# nodemcu1.yaml
substitutions:
  devicename: nodemcu1
<<: !include common.yaml
```

> Tip: Hide base files from dashboard by placing them in a subdirectory or prefixing with `.`

---

## External Components

Load community or custom components not bundled with ESPHome.

```yaml
external_components:
  # From ESPHome GitHub dev branch
  - source:
      type: git
      url: https://github.com/esphome/esphome
      ref: dev
    components: [ rtttl, dfplayer ]

  # GitHub shorthand
  - source: github://esphome/esphome@dev
    components: [ rtttl ]

  # GitHub pull request shorthand
  - source: github://pr#2639
    components: [ rtttl ]

  # All components from a local folder
  - source:
      type: local
      path: my_components

  # Local shorthand
  - source: my_components

  # Local git repository
  - source:
      type: git
      url: file:///Users/user/path_to_repo
      ref: my_awesome_branch
    components: [my_awesome_component]

  # Private git repo with credentials (use !secret)
  - source:
      type: git
      url: https://private-git.example.com/my-components
      username: !secret git_user
      password: !secret git_token
    components: [my_private_component]
    refresh: 1d
```

### Configuration Variables

| Variable | Required | Description |
|----------|----------|-------------|
| `source.type` | Yes | `local` or `git` |
| `source.url` | Git only | Repository URL (`https://`, `http://`, `file://`) |
| `source.ref` | Git optional | Branch or tag name |
| `source.path` | Local required | Path to components folder |
| `source.username` | Git optional | Auth username |
| `source.password` | Git optional | Auth password |
| `components` | Optional | List of component names to use (default: all) |
| `refresh` | Optional | How often to check for updates (default: `1d`, use `never` for tags) |

### Local Component Folder Structure

```
<CONFIG_DIR>/
├── my_device.yaml
└── my_components/
    ├── my_sensor/
    │   ├── __init__.py
    │   ├── my_sensor.cpp
    │   ├── my_sensor.h
    │   └── sensor.py
    └── my_switch/
        ├── __init__.py
        ├── my_switch.cpp
        ├── my_switch.h
        └── switch.py
```

### Git Component Repository Structure

```
# Preferred (for dedicated component repos)
components/
  my_component/
    __init__.py
    component.cpp
    component.h
    sensor.py

# Alternative (for ESPHome forks)
esphome/
  components/
    my_component/
      ...
```

> ESPHome clones repos into `.esphome/` cache. Different `ref` values = separate cache entries.

---

## YAML Structure Order

A well-organized ESPHome config follows this order:

```yaml
substitutions:      # Device identity and secrets

esphome:            # Name, platform options, on_boot

esp32:              # Board, framework, sdkconfig
# or esp8266:

psram:              # If applicable (ESP32-S3)

logger:

packages:           # Common includes (api, ota, wifi)

wifi:               # Static IP override if needed

i2c:                # Bus configuration

spi:                # If needed

output:             # PWM for backlight

light:              # Backlight control

touchscreen:        # Touch controller

display:            # Display driver and pin mapping

image:              # Icon/image definitions

font:               # Custom font definitions

lvgl:               # LVGL config (pages, widgets, styles)

sensor:             # HA sensor imports + handlers

text_sensor:        # HA text sensor imports + handlers

binary_sensor:      # Touch zones, physical buttons

switch:             # LVGL platform switches for HA sync

number:             # LVGL platform number components

button:             # Template buttons, restart, etc.
```

### Naming Conventions

| Element | Convention | Example |
|---------|-----------|---------|
| IDs | `lowercase_snake_case` | `solar_power_label` |
| Substitutions | `lowercase_snake_case` | `display_width` |
| LVGL button IDs | `btn_` prefix | `btn_auto_mode` |
| LVGL switch IDs | `sw_` prefix | `sw_living_room` |
| LVGL image IDs | `img_` prefix | `img_weather_icon` |
| Sensor-linked widgets | match sensor name | `solar_needle`, `temp_label` |

---

## Hardware Configuration

### ESP32-S3 with PSRAM

```yaml
esphome:
  platformio_options:
    board_build.arduino.memory_type: qio_opi
    board_build.flash_mode: qio

esp32:
  board: esp32-s3-devkitc-1
  variant: esp32s3
  framework:
    type: esp-idf
    sdkconfig_options:
      CONFIG_ESP32S3_DATA_CACHE_LINE_64B: "y"
      CONFIG_SPIRAM_FETCH_INSTRUCTIONS: "y"
      CONFIG_SPIRAM_RODATA: "y"

psram:
  mode: octal
  speed: 80MHz
```

### Display Drivers

```yaml
# ST7789V
display:
  - platform: st7789v
    model: CUSTOM
    width: 320
    height: 240
    id: my_display

# ILI9341
display:
  - platform: ili9xxx
    model: ILI9341
    id: my_display

# RGB parallel (800×480 panels)
display:
  - platform: rpi_dpi_rgb
    width: 800
    height: 480
    id: my_display
```

### Touchscreen Controllers

```yaml
# FT5x06 (capacitive, I2C)
touchscreen:
  - platform: ft5x06
    address: 0x38
    id: my_touch

# GT911 (capacitive, I2C)
touchscreen:
  - platform: gt911
    address: 0x5D
    id: my_touch

# XPT2046 (resistive, SPI)
touchscreen:
  - platform: xpt2046
    id: my_touch
    cs_pin: GPIO33
    interrupt_pin: GPIO36
    swap_x_y: false

# With calibration / transform for rotated displays
touchscreen:
  - platform: ft5x06
    id: my_touch
    transform:
      mirror_x: true
      mirror_y: false
      swap_xy: true
    calibration:
      x_min: 0
      x_max: 319
      y_min: 0
      y_max: 479
```

### Backlight Control

```yaml
output:
  - platform: ledc
    pin: GPIO45
    id: backlight_pwm

light:
  - platform: monochromatic
    output: backlight_pwm
    id: backlight
    name: "${friendly_name} Backlight"
    default_transition_length: 500ms
    restore_mode: RESTORE_DEFAULT_ON
```

### Rotary Encoder Input

```yaml
sensor:
  - platform: rotary_encoder
    id: rotary_enc
    pin_a: GPIO1
    pin_b: GPIO2
    on_value:
      then:
        - lambda: |-
            // x is the accumulated count
            int delta = (int)x;
            id(rotary_enc).set_value(0);  // reset after reading
```

---

## Fonts

```yaml
font:
  # Built-in Montserrat (recommended)
  - file: "gfonts://Montserrat"
    id: font_14
    size: 14
    bpp: 4
    extras:
      - file: "gfonts://Montserrat"
        glyphs: "°%/·→←↑↓"

  - file: "gfonts://Montserrat"
    id: font_48
    size: 48
    bpp: 4

  # MDI icon font
  - file: "https://github.com/Templarian/MaterialDesign-Webfont/raw/master/fonts/materialdesignicons-webfont.ttf"
    id: font_icons_32
    size: 32
    bpp: 4
    glyphs:
      - "\U000F0594"   # mdi:weather-sunny
      - "\U000F0597"   # mdi:weather-rainy
      - "\U000F059D"   # mdi:weather-snowy
      - "\U000F0598"   # mdi:weather-cloudy
      - "\U000F06D4"   # mdi:home
      - "\U000F0438"   # mdi:lightbulb
      - "\U000F050F"   # mdi:thermometer
```

---

## Lambda Reference

### Lambda Syntax Patterns

```yaml
# Basic value update
on_value:
  then:
    - lambda: |-
        auto val = x;   # x is the new sensor value (float)
        lv_label_set_text_fmt(id(my_label).obj, "%.1f W", val);

# Conditional color
on_value:
  then:
    - lambda: |-
        if (x > 0) {
          lv_obj_set_style_text_color(id(lbl).obj,
            lv_color_hex(0x00C851), LV_PART_MAIN);
        } else {
          lv_obj_set_style_text_color(id(lbl).obj,
            lv_color_hex(0xFF3D00), LV_PART_MAIN);
        }

# String formatting from float
- lambda: |-
    char buf[16];
    snprintf(buf, sizeof(buf), "%.0f%%", x);
    lv_label_set_text(id(my_label).obj, buf);
```

### Accessing ESPHome Components in Lambdas

```cpp
// Read sensor value
float val = id(my_sensor).state;

// Direct LVGL object access
lv_obj_t *obj = id(my_widget).obj;
lv_label_set_text(obj, "hello");
lv_label_set_text_fmt(obj, "%.1f°C", val);

// Meter needle
lv_meter_set_indicator_value(id(my_meter).obj, id(my_indicator), (int)x);

// Show/hide widget
lv_obj_add_flag(id(my_widget).obj, LV_OBJ_FLAG_HIDDEN);
lv_obj_clear_flag(id(my_widget).obj, LV_OBJ_FLAG_HIDDEN);
```

### Edge Case Handling (Always Use in HA Sensors)

```cpp
// Guard NaN from HA
if (!std::isnan(x)) {
  lv_label_set_text_fmt(id(lbl).obj, "%.1f", x);
} else {
  lv_label_set_text(id(lbl).obj, "--");
}

// Guard sentinel values
if (x < -900 || std::isnan(x)) {
  lv_label_set_text(id(lbl).obj, "?");
  return;
}
```

### Type Conversions

```cpp
float f = id(my_sensor).state;
int i   = (int)f;
int rounded = (int)round(f);

// float → string
std::string s = to_string((int)f);

// string → c-string for LVGL
std::string val = x;  // text_sensor value
lv_label_set_text(id(lbl).obj, val.c_str());
```

---

## Home Assistant Integration

### Bidirectional State Sync (3-Step Pattern)

```yaml
# Step 1: Import HA state → ESPHome switch mirror
switch:
  - platform: homeassistant
    id: ha_light_state
    entity_id: light.living_room
    on_state:
      - lvgl.widget.update:
          id: sw_living_room
          state:
            checked: !lambda return x;

# Step 2: LVGL platform switch (display ↔ HA)
switch:
  - platform: lvgl
    widget: sw_living_room
    name: "Living Room Light"
    # write-back to HA is automatic
```

### Importing Sensor Data

```yaml
sensor:
  - platform: homeassistant
    id: solar_power
    entity_id: sensor.solar_power_w
    on_value:
      then:
        - if:
            condition:
              lambda: return !std::isnan(x);
            then:
              - lvgl.label.update:
                  id: solar_label
                  text: !lambda |-
                    char buf[16];
                    snprintf(buf, sizeof(buf), "%.0f W", x);
                    return std::string(buf);
              - lvgl.indicator.update:
                  id: solar_needle
                  value: !lambda return (int)x;
```

### Importing Text Sensor Data

```yaml
text_sensor:
  - platform: homeassistant
    id: weather_condition
    entity_id: weather.home
    on_value:
      then:
        - lambda: |-
            if (x == "sunny") {
              lv_label_set_text(id(weather_icon).obj, "\U000F0594");
            } else if (x == "rainy") {
              lv_label_set_text(id(weather_icon).obj, "\U000F0597");
            } else {
              lv_label_set_text(id(weather_icon).obj, "\U000F0598");
            }
```

### Calling HA Actions from ESPHome

```yaml
button:
  - platform: template
    name: "Toggle Living Room Light"
    on_press:
      - homeassistant.action:
          action: light.toggle
          data:
            entity_id: light.living_room

# With dynamic data
      - homeassistant.action:
          action: climate.set_temperature
          data:
            entity_id: climate.living_room
            temperature: !lambda return id(temp_setpoint).state;
```

### Boot-time State Initialization

```yaml
esphome:
  on_boot:
    priority: -100
    then:
      - wait_until:
          condition:
            api.connected:
      - delay: 2s
      # Trigger sensor re-publish to populate display
      - component.update: solar_power
      - component.update: battery_soc
```

---
---