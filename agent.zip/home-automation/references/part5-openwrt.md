# Part 5: OpenWrt Integration

> **Freshness:** Basiert auf OpenWrt 23.05 / 24.10 · Geprüft 2025-01
> ubus-Pfade und rpcd-Methoden können sich zwischen Releases ändern — bei unbekannten Endpunkten: https://openwrt.org/docs/techref/ubus gegenchecken.

---

## Architecture

OpenWrt exposes its API via:
- **ubus** — Unix socket (local only) or JSON-RPC over HTTP
- **rpcd** — HTTP JSON-RPC daemon (remote access)
- **UCI** — Unified Configuration Interface (for reading/writing config)

For HA integration: call rpcd via HTTP from `api.py` (Part 3).

---

## rpcd JSON-RPC API

All calls follow this structure:

```python
import aiohttp

async def ubus_call(
    session: aiohttp.ClientSession,
    host: str,
    auth_token: str,
    namespace: str,
    method: str,
    params: dict,
) -> dict:
    payload = {
        "jsonrpc": "2.0",
        "id": 1,
        "method": "call",
        "params": [auth_token, namespace, method, params],
    }
    async with session.post(
        f"http://{host}/ubus",
        json=payload,
        timeout=aiohttp.ClientTimeout(total=10),
    ) as resp:
        resp.raise_for_status()
        result = await resp.json()
        # result["result"] = [status_code, data]
        if result["result"][0] != 0:
            raise OpenWrtApiError(f"ubus error: {result['result'][0]}")
        return result["result"][1]
```

### Authentication

```python
async def async_get_auth_token(
    session: aiohttp.ClientSession,
    host: str,
    username: str,
    password: str,
) -> str:
    """Get session token. Token is valid for ~5 minutes."""
    payload = {
        "jsonrpc": "2.0",
        "id": 1,
        "method": "call",
        "params": [
            "00000000000000000000000000000000",  # empty token for auth
            "session",
            "login",
            {"username": username, "password": password},
        ],
    }
    async with session.post(f"http://{host}/ubus", json=payload) as resp:
        resp.raise_for_status()
        result = await resp.json()
        return result["result"][1]["ubus_rpc_session"]
```

---

## Common ubus Calls

### System Status

```python
# Get system info (uptime, memory, load)
data = await ubus_call(session, host, token, "system", "info", {})
# Returns: {"uptime": 12345, "memory": {...}, "localtime": 1234567890}

uptime_seconds = data["uptime"]
memory_free = data["memory"]["free"]
memory_total = data["memory"]["total"]
```

### Network Interfaces

```python
# Get all interface status
data = await ubus_call(session, host, token, "network.interface", "dump", {})
interfaces = data["interface"]

# Get specific interface
data = await ubus_call(session, host, token, "network.interface.wan", "status", {})
is_up = data["up"]
ipv4 = data.get("ipv4-address", [{}])[0].get("address", "")
```

### WiFi Status

```python
# List all WiFi devices
data = await ubus_call(session, host, token, "network.wireless", "status", {})

# Get associated clients
data = await ubus_call(session, host, token, "hostapd.wlan0", "get_clients", {})
clients = data.get("clients", {})
# clients = {"aa:bb:cc:dd:ee:ff": {"signal": -65, "rx_bytes": 1234, ...}}
```

### Connected Clients / Device Tracker

```python
# Get DHCP leases (all connected clients)
data = await ubus_call(session, host, token, "luci-rpc", "getDHCPLeases", {})
leases = data.get("dhcp_leases", [])
# Each lease: {"mac": "aa:bb:...", "hostname": "phone", "ipaddr": "192.168.1.10"}

# Alternative: ARP table
data = await ubus_call(session, host, token, "luci-rpc", "getNetworkDevices", {})
```

### UCI Configuration

```python
# Read a config value
data = await ubus_call(session, host, token, "uci", "get", {
    "config": "network",
    "section": "wan",
    "option": "proto",
})
# Returns: {"value": "dhcp"}

# Write a config value
await ubus_call(session, host, token, "uci", "set", {
    "config": "network",
    "section": "wan",
    "values": {"proto": "static", "ipaddr": "192.168.1.1"},
})

# Apply changes
await ubus_call(session, host, token, "uci", "commit", {"config": "network"})
await ubus_call(session, host, token, "network", "reload", {})
```

### WiFi Toggle

```python
# Turn off WiFi radio
await ubus_call(session, host, token, "network.wireless", "down", {})

# Turn on WiFi radio
await ubus_call(session, host, token, "network.wireless", "up", {})
```

---

## OpenWrt HA Integration API Layer

```python
# api.py for OpenWrt
from __future__ import annotations
import asyncio
import logging
from typing import Any

import aiohttp

_LOGGER = logging.getLogger(__name__)


class OpenWrtApiError(Exception):
    """OpenWrt API error."""


class OpenWrtApi:
    """Async API client for OpenWrt via rpcd/ubus."""

    def __init__(
        self,
        host: str,
        username: str,
        password: str,
        session: aiohttp.ClientSession,
        timeout: int = 10,
    ) -> None:
        self._host = host
        self._username = username
        self._password = password
        self._session = session
        self._timeout = aiohttp.ClientTimeout(total=timeout)
        self._token: str | None = None

    async def _ensure_token(self) -> str:
        """Get or refresh auth token."""
        if self._token:
            return self._token
        self._token = await self._login()
        return self._token

    async def _login(self) -> str:
        payload = {
            "jsonrpc": "2.0", "id": 1, "method": "call",
            "params": [
                "00000000000000000000000000000000",
                "session", "login",
                {"username": self._username, "password": self._password},
            ],
        }
        async with self._session.post(
            f"http://{self._host}/ubus",
            json=payload,
            timeout=self._timeout,
        ) as resp:
            resp.raise_for_status()
            data = await resp.json()
            return data["result"][1]["ubus_rpc_session"]

    async def _call(self, namespace: str, method: str, params: dict) -> Any:
        token = await self._ensure_token()
        payload = {
            "jsonrpc": "2.0", "id": 1, "method": "call",
            "params": [token, namespace, method, params],
        }
        try:
            async with self._session.post(
                f"http://{self._host}/ubus",
                json=payload,
                timeout=self._timeout,
            ) as resp:
                resp.raise_for_status()
                result = await resp.json()
                code = result["result"][0]
                if code == 6:  # token expired
                    self._token = None
                    return await self._call(namespace, method, params)
                if code != 0:
                    raise OpenWrtApiError(f"ubus error {code}")
                return result["result"][1]
        except aiohttp.ClientError as err:
            raise OpenWrtApiError(f"HTTP error: {err}") from err

    async def async_get_system_info(self) -> dict[str, Any]:
        return await self._call("system", "info", {})

    async def async_get_connected_clients(self) -> list[dict[str, Any]]:
        data = await self._call("luci-rpc", "getDHCPLeases", {})
        return data.get("dhcp_leases", [])

    async def async_get_wifi_clients(self, interface: str = "wlan0") -> dict:
        return await self._call(f"hostapd.{interface}", "get_clients", {})

    async def async_test_connection(self) -> bool:
        try:
            await self.async_get_system_info()
            return True
        except OpenWrtApiError:
            return False
```

---

## Device Tracker Entity for OpenWrt

```python
# device_tracker.py
from __future__ import annotations
from homeassistant.components.device_tracker import ScannerEntity, SourceType
from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant
from homeassistant.helpers.entity_platform import AddEntitiesCallback

from .const import DOMAIN
from .coordinator import MyDeviceCoordinator


async def async_setup_entry(
    hass: HomeAssistant,
    entry: ConfigEntry,
    async_add_entities: AddEntitiesCallback,
) -> None:
    coordinator: MyDeviceCoordinator = hass.data[DOMAIN][entry.entry_id]
    # Dynamic entities: add/remove as clients appear/disappear
    known_macs: set[str] = set()

    def _update_entities() -> None:
        clients = coordinator.data.get("clients", [])
        new_macs = {c["mac"] for c in clients} - known_macs
        if new_macs:
            new_entities = [
                OpenWrtTrackedDevice(coordinator, mac)
                for mac in new_macs
            ]
            async_add_entities(new_entities)
            known_macs.update(new_macs)

    coordinator.async_add_listener(_update_entities)
    _update_entities()


class OpenWrtTrackedDevice(ScannerEntity):
    """Tracked device from OpenWrt DHCP."""

    def __init__(self, coordinator: MyDeviceCoordinator, mac: str) -> None:
        self._coordinator = coordinator
        self._mac = mac.lower()

    @property
    def unique_id(self) -> str:
        return f"{self._coordinator.config_entry.entry_id}_{self._mac}"

    @property
    def name(self) -> str:
        client = self._get_client()
        return client.get("hostname", self._mac) if client else self._mac

    @property
    def is_connected(self) -> bool:
        return self._get_client() is not None

    @property
    def source_type(self) -> SourceType:
        return SourceType.ROUTER

    @property
    def ip_address(self) -> str | None:
        client = self._get_client()
        return client.get("ipaddr") if client else None

    @property
    def mac_address(self) -> str:
        return self._mac

    def _get_client(self) -> dict | None:
        clients = self._coordinator.data.get("clients", [])
        for c in clients:
            if c["mac"].lower() == self._mac:
                return c
        return None
```

---

## Best Practices Summary

| Rule | Detail |
|------|--------|
| Async everywhere | No blocking calls in HA; use `await` + `aiohttp` |
| Network in api.py only | Entities never make HTTP calls directly |
| Guard token expiry | rpcd tokens expire ~5min; retry on error code 6 |
| Handle missing data | `data.get("key")` never `data["key"]` in entity properties |
| Log at DEBUG for data | Use `_LOGGER.debug()` for payloads, `warning()` for errors |
| Test with mocks | Use `unittest.mock.AsyncMock` for all aiohttp calls |