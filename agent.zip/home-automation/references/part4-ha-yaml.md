# Part 4: Home Assistant YAML

> **Freshness:** Basiert auf HA Core 2024.12 · Geprüft 2025-01
> Bei neueren Trigger-Typen, Template-Syntax oder Dashboard-Karten: https://www.home-assistant.io/docs/ gegenchecken.

---

## Automations

```yaml
automation:
  - id: "unique_id_001"
    alias: "Turn on lights at sunset"
    description: "Activates living room lights at sunset"
    trigger:
      - platform: sun
        event: sunset
        offset: "-00:30:00"
    condition:
      - condition: state
        entity_id: binary_sensor.someone_home
        state: "on"
    action:
      - service: light.turn_on
        target:
          entity_id: light.living_room
        data:
          brightness_pct: 50
          color_temp: 3000
    mode: single
```

### Trigger Types

```yaml
trigger:
  # Time
  - platform: time
    at: "07:00:00"

  # State change
  - platform: state
    entity_id: binary_sensor.motion_sensor
    to: "on"
    for:
      seconds: 30

  # Template (condition-based)
  - platform: template
    value_template: "{{ states('sensor.power') | float > 1000 }}"

  # MQTT
  - platform: mqtt
    topic: "home/sensor/data"
    payload: "trigger"
```

### Templates in Automations

```yaml
action:
  - service: notify.mobile_app
    data:
      message: >
        Temperature is {{ states('sensor.living_room_temp') }}°C,
        which is {{ 'above' if states('sensor.living_room_temp') | float > 22 else 'below' }}
        the setpoint.
```

---

## Scripts

```yaml
script:
  morning_routine:
    alias: "Morning Routine"
    sequence:
      - service: light.turn_on
        target:
          entity_id: light.bedroom
        data:
          brightness_pct: 10
      - delay: "00:05:00"
      - service: light.turn_on
        target:
          entity_id: light.kitchen
      - service: climate.set_temperature
        target:
          entity_id: climate.living_room
        data:
          temperature: 21
    mode: single
```

---

## Template Sensors

```yaml
template:
  - sensor:
      - name: "Power State"
        unique_id: power_state_sensor
        state: >
          {% if states('sensor.solar_power') | float > 0 %}
            producing
          {% elif states('sensor.grid_power') | float > 0 %}
            importing
          {% else %}
            idle
          {% endif %}
        unit_of_measurement: ""
        icon: >
          {% if is_state('sensor.power_state', 'producing') %}
            mdi:solar-power
          {% else %}
            mdi:transmission-tower
          {% endif %}
```

---

## Dashboards (Lovelace)

```yaml
# views define pages
views:
  - title: Overview
    path: overview
    icon: mdi:home
    cards:
      # Entity card
      - type: entities
        title: Living Room
        entities:
          - entity: light.living_room
          - entity: climate.living_room
          - entity: sensor.living_room_temperature

      # Gauge card
      - type: gauge
        entity: sensor.solar_power
        name: Solar Power
        unit: W
        min: 0
        max: 5000
        needle: true
        segments:
          - from: 0
            color: "#db4437"
          - from: 1000
            color: "#f4b400"
          - from: 3000
            color: "#0f9d58"

      # Custom button card (button-card)
      - type: custom:button-card
        entity: switch.garden_pump
        name: Garden Pump
        icon: mdi:water-pump
        tap_action:
          action: toggle

      # History graph
      - type: history-graph
        entities:
          - entity: sensor.living_room_temperature
          - entity: sensor.outdoor_temperature
        hours_to_show: 24
        refresh_interval: 60
```

---
---