# HA_PROGRESS.md

## 1. Projekt
**Name:**
**Projektklasse:** ESPHome | ESPHome+LVGL | HA Custom Integration | HA YAML/Dashboard | OpenWrt+HA | Mischprojekt
**Zielbild:**
**Version-Ziel:**

## 2. Systeme und Umgebung
- Home Assistant Version:
- Zielhardware / Board / Router / Device:
- Externe APIs / Systeme:
- Bestehendes Repo oder Dateien:

## 3. Nutzerfluss / Hauptablauf
1.
2.
3.

## 4. Scope
### Must-have
- [ ]
- [ ]
- [ ]

### Out of Scope
- [ ]
- [ ]

## 5. Architekturrahmen
- Domain / Integrationsname:
- Wichtige Entity IDs:
- Wichtige Pins / Busse / Display-Controller:
- Wichtige Endpunkte / Auth-Modelle:
- Wiederverwendete Packages / Templates / Komponenten:

## 6. Risiken und Constraints
### Constraints
- 

### Risiken
- 

### Gegenmaßnahmen
- 

## 7. Definition of Done
- [ ] Erste lauffähige V1 installierbar oder deploybar
- [ ] Kernfluss funktioniert
- [ ] Inbetriebnahme dokumentiert
- [ ] Kritische Risiken bekannt oder behoben

## 8. Task-Graph
### TASK-01
**Prefix:** ESP | INT | YAML | OWR | MIX
**Owner:**
**Depends-On:** []
**Scope:**
**Files/Areas:**
**Output:**
**Acceptance Criteria:**
- [ ]
- [ ]
**Status:** todo

## 9. Delivery Gates
- [ ] Syntax / Struktur plausibel
- [ ] Secrets sauber behandelt
- [ ] Kritischer Kernfluss geprüft
- [ ] Debug-/Testhinweise vorhanden
- [ ] Keine offenen P0/P1-Risiken

## 10. Status
**Aktuelle Phase:**
**Nächster Startpunkt:**
**Letzte Aktualisierung:**
