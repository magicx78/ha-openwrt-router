# HA_WORKING_CONTEXT.md

**Projektklasse:**
**Aktuelles Ziel:**

## Erledigt
- [TASK-XX] [Status/Ergebnis]

## Offen
- [TASK-XX] [Nächster Schritt]

## Entscheidungen
- [Entscheidung + kurze Begründung]

## Kritische Fakten
- Entity IDs:
- Domain:
- Board / Router / Device:
- Pins / Busse:
- APIs / Endpunkte:

## Bekannte Fehler / Blocker
-

## Letzter stabiler Stand
-

## Nächster Schritt
-

## Offene Fragen
- [Nur falls vorhanden]
