# HA Projekt-Workflow

Dieses Dokument steuert den gesamten Ablauf von der Idee bis zur lauffähigen V1.
Lies es, wenn der Nutzer ein Projekt plant, strukturiert, umsetzt oder abschließt.

Fachliche Referenzen (part1–part5) bleiben daneben bestehen — dieses Dokument regelt nur den operativen Rahmen.

---

## Übersicht: 5 Phasen

```
Phase 1: Planung        → HA_PROGRESS.md entsteht
Phase 2: Task-Routing   → Quellen pro Task filtern
Phase 3: Umsetzung      → Tasks delegieren oder selbst ausführen
Phase 4: Checkpoint      → Kontext verdichten bei langen Sessions
Phase 5: Freigabe        → Production-Readiness prüfen
```

Nicht jede Session durchläuft alle Phasen. Wenn schon eine `HA_PROGRESS.md` vorliegt, starte bei Phase 3.

---

## Phase 1 — Planung

### Ziel

Unklare oder grobe Wünsche in ein belastbares Steuerdokument übersetzen.

### Projektklasse festlegen

Kläre immer zuerst genau eine dieser Klassen:
- ESPHome Device
- ESPHome + LVGL Display
- Home Assistant Custom Integration
- HA YAML / Automationen / Dashboard
- OpenWrt + HA
- Mischprojekt (bei Mischprojekten getrennte Teilstränge anlegen)

### Pflichtfragen

Stelle die Fragen nacheinander. Bei unklaren Antworten konkretisieren. Bei Überforderung eine sinnvolle Arbeitsannahme treffen und als solche kenntlich machen.

1. Was soll am Ende konkret funktionieren?
2. Welche Hardware, Geräte oder Systeme sind beteiligt?
3. Läuft schon etwas oder ist es ein Neubau?
4. Welche Plattform ist Ziel der ersten lauffähigen Version?
5. Was sind die 3–5 Must-haves für V1?
6. Was gehört explizit nicht in V1?
7. Gibt es feste Entity IDs, APIs, Pins, Boards, Routermodelle oder Zugangsdaten?
8. Woran erkennst du, dass die erste Version brauchbar ist?
9. Was ist der erste wertvolle Baustein?

### Ergebnis

Fasse die Antworten strukturiert zusammen und lass den Nutzer bestätigen.
Dann erzeuge `HA_PROGRESS.md` nach `templates/HA_PROGRESS.md`.

Regeln:
- Jede Must-have-Anforderung in mindestens eine Task übersetzen
- Jede Task braucht Task-ID, Prefix (ESP|INT|YAML|OWR|MIX), Scope und Acceptance Criteria
- Delivery-Gates vollständig eintragen
- Der Text muss delegierbar sein, nicht nur lesbar

Keine Implementierung beginnen, bevor `HA_PROGRESS.md` bestätigt ist.

---

## Phase 2 — Knowledge Routing

### Ziel

Pro Task nur die maßgeblichen Quellen finden und den Rest wegfiltern.

### Routing-Tabelle

| Projektklasse | Primärquellen | Ergänzend |
|---|---|---|
| ESPHome Device | `references/part1-esphome.md` | Projektinterne YAMLs |
| ESPHome + LVGL | `references/part1-esphome.md` + `references/part2-lvgl.md` | vorhandene Display-Definitionen |
| HA Custom Integration | `references/part3-ha-integration.md` | bestehende `custom_components/` |
| HA YAML / Dashboard | `references/part4-ha-yaml.md` | bestehende Automationen |
| OpenWrt + HA | `references/part5-openwrt.md` + `references/part3-ha-integration.md` | Router-Doku |

Alle Pfade sind relativ zum Skill-Verzeichnis (`references/partX-...`).

### Ausgabe (optional)

Bei komplexen Tasks einen Knowledge Brief nach `templates/HA_KNOWLEDGE_BRIEF.md` schreiben.
Bei einfachen Tasks reicht es, die Quellen im Kopf zu haben.

### Regeln

- Nur taskrelevanten Kontext weitergeben
- Entity IDs, Board-Namen, Pin-Definitionen und Domain-Namen als kritisch markieren
- Veraltete oder blogartige Quellen aktiv abwerten
- Bei Widersprüchen offizielle Primärdoku bevorzugen

---

## Phase 3 — Umsetzung

### Startprotokoll

1. `HA_PROGRESS.md` lesen
2. Optional `HA_WORKING_CONTEXT.md` lesen, falls vorhanden
3. Projektklasse erkennen
4. Nächste sinnvolle Task oder Task-Kette auswählen

Dem Nutzer den aktuellen Stand zeigen:

```
📊 PROJEKT-STATUS
═══════════════════════════════════
📍 Aktueller Stand: [aus HA_PROGRESS.md]
📋 Offene Tasks:    [nächste 2–3 Tasks]
⚠️  Risiken:        [falls vorhanden]
═══════════════════════════════════
```

Dann fragen: *„Hier ist wo wir stehen. Was soll heute passieren?"*

### Umsetzungspfade nach Projektklasse

**A. ESPHome Device**
Hardware und Board validieren → Pins, Busse, Sensoren klären → YAML-Grundstruktur → Secrets und Substitutions auslagern → HA-Anbindung prüfen → Compile-/Flash-Hinweise

**B. ESPHome + LVGL** (zusätzlich zu A)
Display- und Touch-Controller validieren → UI-Struktur und Seitenfluss → LVGL-Widgets klein und testbar → HA-State-Mapping und Guard-Logik

**C. HA Custom Integration**
Domain und Dateiskelett → `manifest.json`, `const.py`, `api.py`, `coordinator.py`, `__init__.py` → `config_flow.py` falls nötig → Entities → Tests und hassfest/HACS-Prüfung

**D. HA YAML / Dashboard**
Entitäten und Trigger verifizieren → Automationen in testbare Blöcke → Template-Risiken prüfen → Debug- und Rollback-Hinweise

**E. OpenWrt + HA**
Ziel-API und Auth klären → Routeraufrufe kapseln → Polling-/Event-Modell → Entities aus `coordinator.data`

### Delegationsregeln

- Pro Task nur Scope, relevante Dateien, Akzeptanzkriterien und ggf. Knowledge Brief übergeben
- Niemals die komplette `HA_PROGRESS.md` ungefiltert in jeden Kontext kippen
- Bei Mischprojekten getrennte Task-Streams pflegen (ESP-xx, INT-xx, YAML-xx)
- Nach jedem Task: Status in `HA_PROGRESS.md` aktualisieren

### Hinweis: Claude.ai vs. Claude Code

In Claude.ai gibt es keine Subagenten. Tasks werden nacheinander abgearbeitet.
Der Workflow bleibt gleich — nur die Parallelität fällt weg. Das ist kein Problem,
solange die Statusführung diszipliniert bleibt.

---

## Phase 4 — Context Checkpoint

### Wann triggern

Spätestens wenn mindestens eines zutrifft:
- drei oder mehr Tasks wurden bearbeitet
- mehrere Entity IDs, Pins, APIs oder Dateipfade stehen im Raum
- Logs oder YAML-Blöcke häufen sich
- der Verlauf beginnt Entscheidungen zu wiederholen
- ungefähr die Hälfte des sinnvoll nutzbaren Kontexts ist erreicht

Keine starre Zahl erzwingen — heuristisch arbeiten, lieber zu früh als zu spät.

### Ausgabe

Schreibe `HA_WORKING_CONTEXT.md` nach `templates/HA_WORKING_CONTEXT.md`.

### Neustart

1. Bestätigen, dass der Checkpoint erstellt wurde
2. Nutzer empfehlen, einen neuen Chat zu starten
3. Im neuen Chat als erstes `HA_PROGRESS.md` und `HA_WORKING_CONTEXT.md` lesen
4. Direkt mit dem nächsten Task weitermachen

### Regeln

- Kein Roman, keine vollständigen Logs, keine kompletten YAML-Dateien kopieren
- Nur Informationen, die für den Neustart nötig sind
- Entscheidungen mit Begründung notieren, wenn sie später wichtig sind

---

## Phase 5 — Production Readiness

### Wann

Sobald alle Must-have-Tasks erfüllt sind oder der Nutzer eine Freigabe anfragt.

### Immer prüfen

- Offensichtliche Konfigurationslücken
- Secrets-Handling
- Fehlerbehandlung
- Debugbarkeit
- Klare Inbetriebnahmehinweise
- Offene P0/P1-Risiken

### Zusatz-Gates nach Projektklasse

**ESPHome:** YAML plausibel, Board/Framework passend, Pins/Busse stimmig, secrets/substitutions genutzt, Boot-Fallbacks bedacht, HA API/Entities plausibel

**ESPHome + LVGL:** Widget-IDs konsistent, Seitenfluss und Touch-Ziele sinnvoll, `on_value`-Handler gegen ungültige Werte geschützt, UI ohne Dead-Ends

**HA Custom Integration:** `manifest.json` korrekt, async-only, DataUpdateCoordinator sauber, Config Flow vorhanden wenn erwartet, Kernpfade getestet, hassfest/HACS geprüft

**HA YAML / Dashboard:** Trigger/Condition/Action logisch, Templates plausibel, Entitäten vorhanden, Fehler-/Rückfallpfade dokumentiert

**OpenWrt + HA:** Auth/Timeout/Error Handling/Polling sauber, keine Netzaufrufe in Entities, Router-Risiken dokumentiert

### Ergebnis

Schreibe `HA_RELEASE_READINESS.md` nach `templates/HA_RELEASE_READINESS.md` mit:
- PASS / CONDITIONAL PASS / FAIL
- Geprüfte Gates
- Mängel und Risiken (P0/P1/P2)
- Restarbeiten
- Empfehlung
