# dev-orchestrator — Global Installation für Claude Code

## Was ist das?

Ein vollständig autonomes Multi-Agent Entwicklungssystem für Claude Code.
Ein Coordinator Agent plant, visualisiert und delegiert an Spezialisten.

```
Coordinator
  ├── OpenWrt Agent
  ├── ESPHome Agent
  ├── HA-Integration Agent
  ├── Blueprint Agent
  └── [Auto-Spawn bei neuen Domains]
```

---

## Installation — Ubuntu/Linux/Mac

```bash
# 1. Skill-Verzeichnis anlegen
mkdir -p ~/.claude/skills

# 2. dev-orchestrator Ordner reinkopieren
cp -r dev-orchestrator ~/.claude/skills/

# 3. Haiku als Standard setzen (günstiger, schnell)
claude config set model claude-haiku-4-5-20251001
```

Fertig. Ab jetzt ist der Skill in **jedem** Projekt aktiv.

---

## Installation — Windows

```powershell
# 1. Skill-Verzeichnis anlegen
mkdir "$env:USERPROFILE\.claude\skills" -Force

# 2. dev-orchestrator Ordner reinkopieren
Copy-Item -Recurse dev-orchestrator "$env:USERPROFILE\.claude\skills\"
```

---

## Verwendung

### Neues Projekt starten

```bash
mkdir mein-projekt && cd mein-projekt
git init
claude
```

Claude fragt automatisch: *"Neues Projekt — was bauen wir?"*

### Bestehendes Projekt öffnen

```bash
cd ha-openwrt-router
claude
```

Claude liest `memory/progress.md` → Coordinator zeigt Status → fragt was heute.

### Einstiegssätze die den Skill triggern

```
"arbeiten wir am projekt"
"neues feature planen"
"was haben wir zuletzt gemacht?"
"blueprint entwickeln"
"integration bauen"
"release vorbereiten"
"was fehlt noch bis zum release?"
```

---

## Projektspezifische Agents

Der globale Skill ist der Rahmen.
Für einzelne Projekte kommen zusätzlich projektspezifische Agents ins Repo:

```
~/.claude/skills/dev-orchestrator/   ← Global (dieser Skill)
mein-projekt/.claude/agents/         ← Projektspezifisch
mein-projekt/CLAUDE.md               ← Projektkontext
mein-projekt/memory/                 ← Gedächtnis (5 Dateien)
```

---

## Memory-Dateien (Gedächtnis)

Das System nutzt 5 Dateien in `memory/` pro Projekt:

| Datei | Inhalt |
|-------|--------|
| `progress.md` | Aktiver Plan, Tasks, aktueller Schritt |
| `architecture.md` | Systemarchitektur, Domains, Interfaces |
| `decisions.md` | Entscheidungen + Begründungen |
| `release.md` | Release-Status, GitHub-Freigabe |
| `agents.md` | Capability Registry, aktive Agents |

Beim ersten Start erstellt der Coordinator `memory/` automatisch.

---

## Modell-Strategie

| Phase | Modell |
|-------|--------|
| Planung, Diagnose, einfache Tasks | Haiku 4.5 (Standard) |
| Komplexe Architektur, langer Code | Sonnet (nur wenn nötig) |

In Session wechseln:
```bash
/model claude-sonnet-4-6          # eskalieren
/model claude-haiku-4-5-20251001  # zurück zu Haiku
```

---

## Skill-Struktur

```
dev-orchestrator/
├── SKILL.md                  ← Router (235 Zeilen)
└── references/
    ├── coordinator.md        ← Vollständiger Coordinator-Workflow
    ├── agents.md             ← Capability Registry + Auto-Spawn
    ├── memory.md             ← Alle 5 Memory-File Templates
    └── publish.md            ← GitHub + CI + Release Workflow
```

---

## Lizenz

MIT — frei verwendbar und anpassbar.
