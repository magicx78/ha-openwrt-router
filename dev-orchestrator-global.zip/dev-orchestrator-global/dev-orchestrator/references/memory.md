# Memory Files — Templates und Struktur

Alle Memory-Dateien leben in `memory/`.
Nur der Coordinator darf sie kanonisch aktualisieren.
Default: nur `progress.md` laden. Andere nur bei Bedarf.

---

## memory/progress.md

```markdown
# Aufgabe
Kurze Beschreibung des aktuellen Ziels.

# Master Plan
1. Schritt
2. Schritt
3. Schritt

# Sub-Tasks
- [ ] TASK-ID — Beschreibung
  Owner: [Agent]
  Status: Offen / In Arbeit / Erledigt ✅

# Aktueller Schritt
[Welche Phase gerade aktiv ist]

# Letzte Session — [DATUM]
[Was wurde gemacht, was entschieden, was offen geblieben]

# Nächste Session
[Was als erstes angegangen werden soll]

# Notizen
[Coordinator-Kommentare, wichtige Kontextinfos]
```

---

## memory/architecture.md

```markdown
# Systemarchitektur

## Domains
- Coordinator — globale Orchestrierung
- [Domain 1] — [Beschreibung]
- [Domain 2] — [Beschreibung]

## Komponenten
| Komponente | Typ | Domain | Beschreibung |
|------------|-----|--------|-------------|
| [Name] | [Typ] | [Domain] | [Was es tut] |

## Integration Points
- [Domain A] → [Domain B]: [Wie sie kommunizieren]

## Interfaces
| Interface | Von | Nach | Protokoll |
|-----------|-----|------|-----------|
| [Name] | [Von] | [Nach] | REST/MQTT/ubus/... |

## Constraints
- [Hardware-Constraint]
- [Software-Constraint]
- [Netzwerk-Constraint]
```

---

## memory/decisions.md

```markdown
# Entscheidungen

## [DATUM] — [Thema]
**Entscheidung:** [Was entschieden wurde]
**Grund:** [Warum]
**Alternativen verworfen:**
- [Alternative A]: [Warum nicht]
- [Alternative B]: [Warum nicht]
**Impact:** [Was sich dadurch ändert]

---
```

---

## memory/release.md

```markdown
# Release Status

## Version
[v0.0.0 — noch nicht released]

## GitHub Freigabe
[ ] Ausstehend / [ ] Erteilt / [ ] Verweigert

## Auto-Publish nach Tests
[ ] Ja / [ ] Nein — manuell

## Test Gate
[ ] Nicht gestartet / [ ] Laufend / [ ] Bestanden / [ ] Fehlgeschlagen

## Dokumentation
- [ ] README.md vollständig
- [ ] CHANGELOG.md aktuell
- [ ] Setup-Anleitung vorhanden
- [ ] Nutzungsanleitung vorhanden
- [ ] Release-Zusammenfassung

## Publish Readiness
- [ ] Implementierung komplett
- [ ] Tests bestanden
- [ ] Keine blockierenden Issues
- [ ] Dokumentation vollständig
- [ ] GitHub-Freigabe erteilt

## Publish-Weg
[ ] Nur lokal
[ ] GitHub (manuell)
[ ] GitHub (automatisch nach Tests)
[ ] HA Community Forum
[ ] HACS Default Store
```

---

## memory/agents.md

```markdown
# Agent Registry

## Active Agents
- Coordinator
- OpenWrt Agent
- ESPHome Agent
- HA-Integration Agent
- Blueprint Agent

## Spawned Agents
(leer — noch keine gespawnt)

## Capability Notes
- OpenWrt: besitzt alles rund um Router, UCI, Firewall
- ESPHome: besitzt alle ESP32/ESPHome Firmware
- HA-Integration: besitzt custom_components Python
- Blueprint: besitzt HA Blueprint YAML + Validierung
- Coordinator: eskaliert wenn Domain-übergreifend
```

---

## Initialisierung (neues Projekt)

```bash
mkdir -p memory
cat > memory/progress.md << 'EOF'
# Aufgabe
[Projektziel eintragen]

# Master Plan
(wird beim ersten Planning Mode erstellt)

# Sub-Tasks
(noch keine)

# Aktueller Schritt
Initialisierung

# Letzte Session — [DATUM]
Projekt gestartet.
EOF

cat > memory/agents.md << 'EOF'
# Agent Registry

## Active Agents
- Coordinator
- [Welche Domains relevant sind]

## Spawned Agents
(leer)
EOF

git add memory/
git commit -m "chore: initialize project memory"
```
