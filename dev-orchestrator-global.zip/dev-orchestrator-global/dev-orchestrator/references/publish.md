# GitHub Publication Workflow

Nur der Coordinator darf ein Repository vorbereiten oder publizieren.

---

## Publish-Freigabe erforderlich

Publication nur wenn:
- [ ] GitHub-Freigabe aus Planning Mode erteilt
- [ ] Tests bestanden
- [ ] Keine blockierenden Issues
- [ ] Dokumentation komplett
- [ ] `memory/release.md` zeigt Publish-Readiness

---

## Schritt 1 — Repo initialisieren

```bash
git init
git branch -M main

cat > .gitignore << 'EOF'
.DS_Store
__pycache__/
*.pyc
.env
*.env
node_modules/
.idea/
.vscode/
EOF
```

---

## Schritt 2 — README.md

Pflicht-Inhalt:
```markdown
# [Projekt-Name]

[![CI](https://github.com/USERNAME/REPO/actions/workflows/validate.yml/badge.svg)](...)

Kurze Beschreibung (1-2 Sätze).

## Features
- Feature 1
- Feature 2

## Installation

### Voraussetzungen
- [Was gebraucht wird]

### Setup
[Schritt-für-Schritt]

## Nutzung
[Wie man es verwendet]

## Architektur
[Kurze Übersicht — Details in docs/architecture.md]

## Contributing
[Wie man beiträgt]

## Lizenz
MIT
```

Für **Blueprints** zusätzlich Import-Buttons:
```markdown
[![Import Blueprint](https://my.home-assistant.io/badges/blueprint_import.svg)](
https://my.home-assistant.io/redirect/blueprint_import/?blueprint_url=
https://raw.githubusercontent.com/USERNAME/REPO/main/blueprints/automation/name.yaml)
```

Für **HA Integrations** HACS-Badge:
```markdown
[![hacs_badge](https://img.shields.io/badge/HACS-Custom-orange.svg)](https://github.com/hacs/integration)
```

---

## Schritt 3 — CHANGELOG.md

```markdown
# Changelog

## [1.0.0] - YYYY-MM-DD
### Added
- Erste stabile Version
- [Feature 1]
- [Feature 2]

### Notes
- [Wichtige Hinweise]
```

---

## Schritt 4 — GitHub Actions CI

### Für HA Integrations:
```yaml
# .github/workflows/validate.yml
name: Validate

on: [push, pull_request]

jobs:
  hassfest:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: home-assistant/actions/hassfest@master

  hacs:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: hacs/action@main
        with:
          CATEGORY: integration

  tests:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with:
          python-version: "3.12"
      - run: pip install pytest pytest-asyncio aiohttp homeassistant
      - run: pytest tests/ -v --asyncio-mode=auto
```

### Für Blueprints:
```yaml
# .github/workflows/validate.yml
name: Validate Blueprints

on:
  push:
    paths: ["blueprints/**/*.yaml"]
  pull_request:
    paths: ["blueprints/**/*.yaml"]

jobs:
  validate:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with:
          python-version: "3.12"
      - run: pip install pyyaml
      - run: |
          python3 -c "
          import yaml, glob, sys
          class HALoader(yaml.SafeLoader): pass
          HALoader.add_constructor('!input', lambda l,n: l.construct_scalar(n))
          errors = []
          for f in glob.glob('blueprints/**/*.yaml', recursive=True):
              try:
                  data = yaml.load(open(f), HALoader)
                  bp = data.get('blueprint', {})
                  if not bp.get('name'): errors.append(f+': name fehlt')
                  if bp.get('domain') not in ['automation','script','template']:
                      errors.append(f+': domain ungültig')
                  print('OK:', f)
              except Exception as e:
                  errors.append(f+': '+str(e))
          if errors:
              [print('FEHLER:', e) for e in errors]
              sys.exit(1)
          "
```

---

## Schritt 5 — Push

```bash
# GitHub Repo muss MANUELL auf github.com erstellt werden
# (Claude Code kann keine Passwörter eingeben)

git remote add origin https://github.com/USERNAME/REPO.git
git add .
git commit -m "feat: initial release v1.0.0"
git push -u origin main
```

---

## Schritt 6 — Release taggen

```bash
git tag v1.0.0
git push origin v1.0.0
```

Auf GitHub: Releases → New Release → Tag auswählen → Notes aus CHANGELOG.

---

## Schritt 7 — Presentation Package

Coordinator generiert nach erfolgreicher Publication:

```markdown
# 🚀 Release Summary — [Projekt] v[Version]

## Was wurde gebaut
[Projekt-Übersicht in 2-3 Sätzen]

## Architektur
[Kurze Beschreibung der Systemarchitektur]

## Was implementiert wurde
- [Feature 1] — [kurze Erklärung]
- [Feature 2] — [kurze Erklärung]

## Tests
[Welche Tests laufen, was sie prüfen]

## Nutzung
[Wie man es installiert/nutzt]

## Bekannte Limitierungen
- [Limitation 1]

## Nächste Schritte
- [Geplante v1.1 Features]

## Links
- GitHub: [URL]
- Import/Install: [URL falls relevant]
```

---

## Publish-Checkliste

- [ ] Git-Repo initialisiert
- [ ] README.md vollständig
- [ ] CHANGELOG.md aktuell
- [ ] CI Workflow grün auf main
- [ ] Mindestens 1 GitHub Release
- [ ] `memory/release.md` aktualisiert
- [ ] Presentation Package generiert

**Für HACS Default Store zusätzlich:**
- [ ] `brand/icon.png` 256×256px
- [ ] `manifest.json` hat `issue_tracker`
- [ ] Repo hat Description + Topics auf GitHub
