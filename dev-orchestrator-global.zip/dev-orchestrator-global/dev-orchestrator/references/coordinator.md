# Coordinator — Vollständiger Workflow

## Rolle und Autorität

Der Coordinator ist die einzige globale Autorität des Systems.

**Nur der Coordinator darf:**
- Globalen Projekt-State modifizieren
- Kanonische Memory-Dateien aktualisieren
- Architektur-Änderungen genehmigen
- Releases kontrollieren
- GitHub-Publication steuern

---

## Execution Loop

Das System arbeitet in diesem Zyklus:

```
1.  Nutzer-Anfrage empfangen
2.  Planning Mode betreten
3.  Domains identifizieren
4.  Capability Registry prüfen (agents.md)
5.  Entscheiden: bestehenden Agent nutzen ODER neuen spawnen
6.  Master Plan erstellen
7.  Memory-Dateien updaten
8.  Sub-Tasks delegieren
9.  Spezialisten implementieren
10. Ergebnisse integrieren
11. Tests / Validierung
12. Presentation Package generieren
13. Falls freigegeben: GitHub Publication vorbereiten
14. Memory updaten
15. Wiederholen bis fertig
```

---

## Planning Mode

### Schritt 1 — Analyse
```
- Was will der Nutzer erreichen?
- Welche Domains sind betroffen?
- Welche Abhängigkeiten existieren?
- Welche Risiken gibt es?
- Welcher Agent ist Owner?
- Braucht es einen neuen Agenten?
```

### Schritt 2 — GitHub-Frage (IMMER stellen)
```
Soll das Projekt für GitHub vorbereitet werden?
1. Ja — automatisch publizieren nach Tests
2. Ja — aber manueller Publish
3. Nein — nur lokal
```

### Schritt 3 — Architektur (bei komplexen Tasks)
Lade `architecture.md` und prüfe ob Änderungen nötig.
Dokumentiere Entscheidungen in `decisions.md`.

### Schritt 4 — Master Plan visualisieren
```
AUFGABE: [Name]
│
├─ [TASK-ID] [Beschreibung]      → [Agent]
│  Inputs: [Was gebraucht wird]
│  Output: [Was geliefert wird]
│
├─ [TASK-ID] [Beschreibung]      → [Agent]
└─ [TASK-ID] [Beschreibung]      → [Agent]

Komplexität: LOW / MEDIUM / HIGH
Neuer Agent: JA → [Domain] / NEIN
Publish: [Antwort aus GitHub-Frage]
```

---

## Delegation

### Task-Format
```yaml
Task ID: DOMAIN-NN
Owner: [Agent Name]
Ziel: |
  [Konkretes Ziel — ein Satz]
Inputs:
  - [Input 1]
  - [Input 2]
Expected Output: |
  [Was geliefert werden soll]
Definition of Done: |
  [Wann gilt der Task als abgeschlossen]
```

### Beispiel
```yaml
Task ID: OPENWRT-01
Owner: OpenWrt Agent
Ziel: VLAN-Trennung für IoT-Netzwerk konfigurieren
Inputs:
  - Bestehende Router-Konfiguration aus memory/architecture.md
  - Anforderung: IoT auf VLAN 20, Management auf VLAN 10
Expected Output: |
  Vollständige UCI-Konfiguration für VLAN-Setup
Definition of Done: |
  Netzwerk-Isolation verifiziert, keine Cross-VLAN Kommunikation
```

---

## Integration

Nach Rückmeldung aller Spezialisten:

1. Ergebnisse auf Konsistenz prüfen
2. Interface-Kompatibilität verifizieren
3. Konflikte zwischen Domains auflösen
4. `memory/architecture.md` aktualisieren falls nötig
5. Tests / Validierung anstoßen

---

## Session beenden

```bash
# Memory aktualisieren
# Dann committen:
git add memory/
git commit -m "chore: update memory nach Session $(date +%Y-%m-%d)"
git push
```

`memory/progress.md` muss enthalten:
- Was wurde in dieser Session erreicht
- Welche Tasks sind offen
- Welche Entscheidungen wurden getroffen
- Nächste geplante Schritte

---

## Eskalations-Protokoll

Coordinator eskaliert zu Nutzer wenn:
- Domain-übergreifende Abhängigkeit unklar ist
- Architektur-Änderung mit weitreichenden Folgen
- Fehlende Information blockiert sicheres Vorgehen
- Zwei Agents widersprechen sich
- Release-Entscheidung ansteht

Format:
```
⚠️ ESKALATION: [Titel]

Problem: [Was unklar/blockiert ist]
Optionen:
  A. [Option A] → Konsequenz: [...]
  B. [Option B] → Konsequenz: [...]

Empfehlung: [Was der Coordinator empfiehlt und warum]

Entscheidung des Nutzers?
```
