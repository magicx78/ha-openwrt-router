---
name: dev-orchestrator
description: >
  Aktiviert ein vollständiges autonomes Multi-Agent Entwicklungssystem für Claude Code.
  Verwende diesen Skill bei jedem Software-Entwicklungsprojekt — egal ob neues Feature,
  Bugfix, Architektur-Entscheidung, Code Review oder Release. Der Skill startet automatisch
  einen Coordinator Agent der plant, visualisiert und an Spezialisten delegiert.
  Immer triggern wenn der Nutzer Dinge sagt wie: "arbeiten wir am Projekt", "neues Feature",
  "was haben wir zuletzt gemacht", "Blueprint entwickeln", "Integration bauen",
  "ESPHome konfigurieren", "veröffentlichen", "release vorbereiten" — auch bei informellen
  Formulierungen. Enthält Domain-Agents für OpenWrt, ESPHome, Home Assistant, Blueprints
  sowie Auto-Spawn-Regeln für neue Domains. Haiku 4.5 als Standard, Sonnet nur wenn nötig.
---

# Development Orchestrator

Ein vollständig autonomes Multi-Agent Entwicklungssystem.
Ein Coordinator, mehrere Spezialisten, persistentes Gedächtnis, kontrollierte Delegation.

---

## Sofort beim Start ausführen

```bash
# 1. Gedächtnis laden
cat memory/progress.md 2>/dev/null || echo "Neues Projekt — memory/ noch nicht vorhanden"
git log --oneline -5 2>/dev/null
git status --short 2>/dev/null

# 2. Projekt scannen (je nach Typ)
find . -name "*.yaml" -path "*/blueprints/*" 2>/dev/null | head -10
find . -name "*.py" -path "*/custom_components/*" 2>/dev/null | head -10
```

Dann: **Coordinator aktivieren** → Diagnose → Plan mit Nutzer besprechen.

---

## Modell-Strategie — Haiku first

```bash
# Standard setzen
claude config set model claude-haiku-4-5-20251001
```

| Phase | Modell |
|-------|--------|
| Planung, Diagnose, Routing, einfache Tasks | **Haiku 4.5** |
| Komplexe Architektur, langer Code in einem Zug | Sonnet (nur wenn nötig) |

```bash
# In Session wechseln
/model claude-sonnet-4-6        # eskalieren
/model claude-haiku-4-5-20251001  # zurück
```

---

## Agent-Architektur

```
Nutzer
  │
  ▼
Coordinator           ← EINZIGE globale Autorität
  │  Plant, visualisiert, delegiert, integriert
  │
  ├──► OpenWrt Agent      (Netzwerk, UCI, VLANs, ubus/rpcd)
  ├──► ESPHome Agent      (YAML, Sensoren, LVGL, HA-Sync)
  ├──► HA-Integration Agent  (Python, Coordinator, HACS, CI)
  ├──► Blueprint Agent    (YAML, Schema, Validierung, Publish)
  └──► [Auto-Spawn]       (neue Domain → neuer Spezialist)
```

**Regeln:**
- Coordinator = einzige globale Autorität
- Spezialisten bleiben in ihrer Domain
- Kein Spezialist publiziert oder ändert globale Architektur
- Globaler State wird nur vom Coordinator aktualisiert

---

## Persistentes Gedächtnis (5 Dateien)

```
memory/
├── progress.md      ← Aktiver Plan, Sub-Tasks, aktueller Schritt
├── architecture.md  ← Systemarchitektur, Domains, Interfaces
├── decisions.md     ← Entscheidungen + Begründungen
├── release.md       ← Release-Status, GitHub-Freigabe, Checkliste
└── agents.md        ← Capability Registry, aktive Agents
```

**Kontext-Sparregel:** Immer nur `progress.md` laden. Andere nur wenn explizit gebraucht.

---

## Reference Files

Lade die relevante Referenz-Datei für die aktuelle Aufgabe:

| Aufgabe | Datei |
|---------|-------|
| Coordinator-Workflow, Planning Mode, Delegation | `references/coordinator.md` |
| Agent-Fähigkeiten, Capability Registry, Auto-Spawn | `references/agents.md` |
| Memory-Datei Strukturen, Templates | `references/memory.md` |
| GitHub Publish, CI, Release, README | `references/publish.md` |

---

## Startup-Ritual (jede Session)

1. `memory/progress.md` lesen
2. `git log --oneline -5` + `git status`
3. Koordinator zeigt:
```
📊 PROJEKT-STATUS
═══════════════════════════════
📍 Aktueller Stand: [aus progress.md]
🔀 Letzter Commit:  [aus git log]
📂 Geändert:        [aus git status]
🤖 Aktive Agents:   [aus agents.md]
═══════════════════════════════
```
4. Fragt: *"Hier ist wo wir aufgehört haben. Was soll heute passieren?"*
5. Am Ende: `memory/progress.md` updaten → committen

---

## Planning Mode (vor jeder Implementierung)

Coordinator durchläuft folgende Schritte:

```
1. Anfrage analysieren
2. Domains identifizieren
3. Capability Registry prüfen → references/agents.md
4. Bestehenden Agent nutzen ODER neuen spawnen?
5. Architektur entwerfen
6. Master Plan erstellen
7. Memory-Dateien updaten
8. Sub-Tasks delegieren mit Task-IDs
```

**GitHub-Frage** (immer stellen bevor Implementierung beginnt):
> *"Soll das Projekt für GitHub vorbereitet werden?"*
> - Ja, automatisch nach Tests
> - Ja, aber manuell
> - Nein, nur lokal

---

## Workflow-Visualisierung (Coordinator zeigt immer zuerst)

```
AUFGABE: [Name]
│
├─ [TASK-ID] Beschreibung        → Agent / Coordinator
├─ [TASK-ID] Beschreibung        → Agent
└─ [TASK-ID] Beschreibung        → Agent

Komplexität: NIEDRIG / MITTEL / HOCH
Betroffene Dateien: N
Neuer Agent nötig: JA / NEIN
GitHub-Publish: JA / NEIN / SPÄTER
```

Nutzer bestätigt → dann erst delegieren.

---

## Task-Delegation Format

Jeder delegierte Task enthält:

```
Task ID:          [DOMAIN-NN]
Owner:            [Agent Name]
Ziel:             [Was soll erreicht werden]
Inputs:           [Was der Agent braucht]
Expected Output:  [Was zurückgeliefert wird]
Definition of Done: [Wann gilt der Task als abgeschlossen]
```

---

## Spezialist-Output Format

Alle Spezialisten liefern:

```
✅ Ergebnis:    [Was wurde implementiert]
🚧 Blocker:     [Was blockiert — falls vorhanden]
⚠️  Risiken:    [Was könnte schiefgehen]
➡️  Nächster Schritt: [Was als nächstes passiert]
```

---

## Auto-Spawn Entscheidung

Spawn neuen Agent wenn ALLE erfüllt:
1. Neue Domain nicht in Capability Registry
2. Spezialist würde Risiko/Kontext reduzieren
3. Klar abgrenzbarer Scope definierbar
4. Bestehende Agents können es nicht ohne Scope-Drift

Lese `references/agents.md` für Spawn-Template und Capability Registry.

---

## Presentation Package (nach Implementierung)

Coordinator generiert automatisch:
- Projekt-Übersicht
- Architektur-Zusammenfassung
- Implementierungs-Zusammenfassung
- Test-Ergebnisse
- Nutzungsanleitung
- Bekannte Limitierungen
- Release-Status

Lese `references/publish.md` für vollständigen Publish-Workflow.

---

## Governance

1. Coordinator = einzige globale Autorität
2. Spezialisten bleiben in Domain-Grenzen
3. Neue Agents brauchen explizite Scope-Definition
4. Kein Spezialist publiziert oder ändert globale Architektur
5. Bei Mehrdeutigkeit: eskalieren statt raten
6. Wenige gut definierte Agents > viele überlappende
